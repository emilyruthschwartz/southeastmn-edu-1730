﻿
namespace ex1f
{
    partial class frmCurrencyConverter2
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCurrencyConverter2));
            this.picChile = new System.Windows.Forms.PictureBox();
            this.picChileDim = new System.Windows.Forms.PictureBox();
            this.picEU = new System.Windows.Forms.PictureBox();
            this.picEUDim = new System.Windows.Forms.PictureBox();
            this.picIndonesia = new System.Windows.Forms.PictureBox();
            this.picIndonesiaDim = new System.Windows.Forms.PictureBox();
            this.picNZ = new System.Windows.Forms.PictureBox();
            this.picNZDim = new System.Windows.Forms.PictureBox();
            this.btnChile = new System.Windows.Forms.Button();
            this.btnEU = new System.Windows.Forms.Button();
            this.btnIndonesia = new System.Windows.Forms.Button();
            this.btnNZ = new System.Windows.Forms.Button();
            this.lblCurrency = new System.Windows.Forms.Label();
            this.txtCurrency = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.txtUSD = new System.Windows.Forms.TextBox();
            this.lblEquation = new System.Windows.Forms.Label();
            this.txtTotalUSD = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picChile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChileDim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEUDim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIndonesia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIndonesiaDim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNZDim)).BeginInit();
            this.SuspendLayout();
            // 
            // picChile
            // 
            this.picChile.Image = ((System.Drawing.Image)(resources.GetObject("picChile.Image")));
            this.picChile.Location = new System.Drawing.Point(3, 380);
            this.picChile.Name = "picChile";
            this.picChile.Size = new System.Drawing.Size(91, 71);
            this.picChile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picChile.TabIndex = 0;
            this.picChile.TabStop = false;
            this.picChile.Visible = false;
            // 
            // picChileDim
            // 
            this.picChileDim.Image = ((System.Drawing.Image)(resources.GetObject("picChileDim.Image")));
            this.picChileDim.Location = new System.Drawing.Point(100, 380);
            this.picChileDim.Name = "picChileDim";
            this.picChileDim.Size = new System.Drawing.Size(91, 71);
            this.picChileDim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picChileDim.TabIndex = 1;
            this.picChileDim.TabStop = false;
            this.picChileDim.Visible = false;
            // 
            // picEU
            // 
            this.picEU.Image = ((System.Drawing.Image)(resources.GetObject("picEU.Image")));
            this.picEU.Location = new System.Drawing.Point(197, 380);
            this.picEU.Name = "picEU";
            this.picEU.Size = new System.Drawing.Size(91, 71);
            this.picEU.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEU.TabIndex = 2;
            this.picEU.TabStop = false;
            this.picEU.Visible = false;
            // 
            // picEUDim
            // 
            this.picEUDim.Image = ((System.Drawing.Image)(resources.GetObject("picEUDim.Image")));
            this.picEUDim.Location = new System.Drawing.Point(294, 380);
            this.picEUDim.Name = "picEUDim";
            this.picEUDim.Size = new System.Drawing.Size(91, 71);
            this.picEUDim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEUDim.TabIndex = 3;
            this.picEUDim.TabStop = false;
            this.picEUDim.Visible = false;
            // 
            // picIndonesia
            // 
            this.picIndonesia.Image = ((System.Drawing.Image)(resources.GetObject("picIndonesia.Image")));
            this.picIndonesia.Location = new System.Drawing.Point(391, 380);
            this.picIndonesia.Name = "picIndonesia";
            this.picIndonesia.Size = new System.Drawing.Size(91, 71);
            this.picIndonesia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picIndonesia.TabIndex = 4;
            this.picIndonesia.TabStop = false;
            this.picIndonesia.Visible = false;
            // 
            // picIndonesiaDim
            // 
            this.picIndonesiaDim.Image = ((System.Drawing.Image)(resources.GetObject("picIndonesiaDim.Image")));
            this.picIndonesiaDim.Location = new System.Drawing.Point(488, 380);
            this.picIndonesiaDim.Name = "picIndonesiaDim";
            this.picIndonesiaDim.Size = new System.Drawing.Size(91, 71);
            this.picIndonesiaDim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picIndonesiaDim.TabIndex = 5;
            this.picIndonesiaDim.TabStop = false;
            this.picIndonesiaDim.Visible = false;
            // 
            // picNZ
            // 
            this.picNZ.Image = ((System.Drawing.Image)(resources.GetObject("picNZ.Image")));
            this.picNZ.Location = new System.Drawing.Point(585, 380);
            this.picNZ.Name = "picNZ";
            this.picNZ.Size = new System.Drawing.Size(91, 71);
            this.picNZ.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picNZ.TabIndex = 6;
            this.picNZ.TabStop = false;
            this.picNZ.Visible = false;
            // 
            // picNZDim
            // 
            this.picNZDim.Image = ((System.Drawing.Image)(resources.GetObject("picNZDim.Image")));
            this.picNZDim.Location = new System.Drawing.Point(682, 380);
            this.picNZDim.Name = "picNZDim";
            this.picNZDim.Size = new System.Drawing.Size(91, 71);
            this.picNZDim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picNZDim.TabIndex = 7;
            this.picNZDim.TabStop = false;
            this.picNZDim.Visible = false;
            // 
            // btnChile
            // 
            this.btnChile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChile.Location = new System.Drawing.Point(10, 21);
            this.btnChile.Name = "btnChile";
            this.btnChile.Size = new System.Drawing.Size(172, 175);
            this.btnChile.TabIndex = 8;
            this.btnChile.TabStop = false;
            this.btnChile.Text = "Chilean Peso";
            this.btnChile.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnChile.UseVisualStyleBackColor = true;
            this.btnChile.Click += new System.EventHandler(this.btnChile_Click);
            // 
            // btnEU
            // 
            this.btnEU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEU.Location = new System.Drawing.Point(204, 21);
            this.btnEU.Name = "btnEU";
            this.btnEU.Size = new System.Drawing.Size(172, 175);
            this.btnEU.TabIndex = 9;
            this.btnEU.TabStop = false;
            this.btnEU.Text = "Euro";
            this.btnEU.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEU.UseVisualStyleBackColor = true;
            this.btnEU.Click += new System.EventHandler(this.btnEU_Click);
            // 
            // btnIndonesia
            // 
            this.btnIndonesia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIndonesia.Location = new System.Drawing.Point(398, 21);
            this.btnIndonesia.Name = "btnIndonesia";
            this.btnIndonesia.Size = new System.Drawing.Size(172, 175);
            this.btnIndonesia.TabIndex = 10;
            this.btnIndonesia.TabStop = false;
            this.btnIndonesia.Text = "Indonesian Rupiah";
            this.btnIndonesia.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnIndonesia.UseVisualStyleBackColor = true;
            this.btnIndonesia.Click += new System.EventHandler(this.btnIndonesia_Click);
            // 
            // btnNZ
            // 
            this.btnNZ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNZ.Location = new System.Drawing.Point(592, 21);
            this.btnNZ.Name = "btnNZ";
            this.btnNZ.Size = new System.Drawing.Size(172, 175);
            this.btnNZ.TabIndex = 11;
            this.btnNZ.TabStop = false;
            this.btnNZ.Text = "New Zealand Dollar";
            this.btnNZ.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNZ.UseVisualStyleBackColor = true;
            this.btnNZ.Click += new System.EventHandler(this.btnNZ_Click);
            // 
            // lblCurrency
            // 
            this.lblCurrency.BackColor = System.Drawing.Color.Silver;
            this.lblCurrency.Location = new System.Drawing.Point(12, 210);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(170, 26);
            this.lblCurrency.TabIndex = 12;
            this.lblCurrency.Text = "Chilean Peso:";
            this.lblCurrency.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCurrency
            // 
            this.txtCurrency.Location = new System.Drawing.Point(204, 210);
            this.txtCurrency.Name = "txtCurrency";
            this.txtCurrency.Size = new System.Drawing.Size(165, 27);
            this.txtCurrency.TabIndex = 1;
            this.txtCurrency.Text = "0.00";
            this.txtCurrency.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCurrency.Click += new System.EventHandler(this.txtCurrency_Enter);
            this.txtCurrency.TextChanged += new System.EventHandler(this.calcUSD);
            this.txtCurrency.Enter += new System.EventHandler(this.txtCurrency_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Rate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "$US";
            // 
            // txtRate
            // 
            this.txtRate.Location = new System.Drawing.Point(204, 244);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(165, 27);
            this.txtRate.TabIndex = 2;
            this.txtRate.Text = "0.00";
            this.txtRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRate.TextChanged += new System.EventHandler(this.calcUSD);
            // 
            // txtUSD
            // 
            this.txtUSD.Location = new System.Drawing.Point(204, 277);
            this.txtUSD.Name = "txtUSD";
            this.txtUSD.ReadOnly = true;
            this.txtUSD.Size = new System.Drawing.Size(165, 27);
            this.txtUSD.TabIndex = 17;
            this.txtUSD.TabStop = false;
            this.txtUSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblEquation
            // 
            this.lblEquation.BackColor = System.Drawing.Color.Silver;
            this.lblEquation.Location = new System.Drawing.Point(12, 313);
            this.lblEquation.Name = "lblEquation";
            this.lblEquation.Size = new System.Drawing.Size(164, 61);
            this.lblEquation.TabIndex = 18;
            // 
            // txtTotalUSD
            // 
            this.txtTotalUSD.Location = new System.Drawing.Point(204, 313);
            this.txtTotalUSD.Name = "txtTotalUSD";
            this.txtTotalUSD.ReadOnly = true;
            this.txtTotalUSD.Size = new System.Drawing.Size(165, 27);
            this.txtTotalUSD.TabIndex = 19;
            this.txtTotalUSD.TabStop = false;
            this.txtTotalUSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalUSD.TextChanged += new System.EventHandler(this.calcUSD);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(204, 345);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(165, 29);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(375, 345);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(165, 29);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAdd.Location = new System.Drawing.Point(391, 277);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(37, 27);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "+";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // frmCurrencyConverter2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 454);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtTotalUSD);
            this.Controls.Add(this.lblEquation);
            this.Controls.Add(this.txtUSD);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCurrency);
            this.Controls.Add(this.lblCurrency);
            this.Controls.Add(this.btnNZ);
            this.Controls.Add(this.btnIndonesia);
            this.Controls.Add(this.btnEU);
            this.Controls.Add(this.btnChile);
            this.Controls.Add(this.picNZDim);
            this.Controls.Add(this.picNZ);
            this.Controls.Add(this.picIndonesiaDim);
            this.Controls.Add(this.picIndonesia);
            this.Controls.Add(this.picEUDim);
            this.Controls.Add(this.picEU);
            this.Controls.Add(this.picChileDim);
            this.Controls.Add(this.picChile);
            this.Name = "frmCurrencyConverter2";
            this.Text = "ex1f: Currency Converter v2";
            this.Load += new System.EventHandler(this.frmCurrencyConverter2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picChile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChileDim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEUDim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIndonesia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIndonesiaDim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNZDim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picChile;
        private System.Windows.Forms.PictureBox picChileDim;
        private System.Windows.Forms.PictureBox picEU;
        private System.Windows.Forms.PictureBox picEUDim;
        private System.Windows.Forms.PictureBox picIndonesia;
        private System.Windows.Forms.PictureBox picIndonesiaDim;
        private System.Windows.Forms.PictureBox picNZ;
        private System.Windows.Forms.PictureBox picNZDim;
        private System.Windows.Forms.Button btnChile;
        private System.Windows.Forms.Button btnEU;
        private System.Windows.Forms.Button btnIndonesia;
        private System.Windows.Forms.Button btnNZ;
        private System.Windows.Forms.Label lblCurrency;
        private System.Windows.Forms.TextBox txtCurrency;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.TextBox txtUSD;
        private System.Windows.Forms.Label lblEquation;
        private System.Windows.Forms.TextBox txtTotalUSD;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAdd;
    }
}

