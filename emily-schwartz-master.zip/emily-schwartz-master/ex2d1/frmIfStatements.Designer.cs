﻿
namespace ex2d1
{
    partial class frmIfStatements
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1Input = new System.Windows.Forms.TextBox();
            this.textBox2Input = new System.Windows.Forms.TextBox();
            this.textBox3Input = new System.Windows.Forms.TextBox();
            this.textBox4Input = new System.Windows.Forms.TextBox();
            this.textBox5InputA = new System.Windows.Forms.TextBox();
            this.textBox5InputB = new System.Windows.Forms.TextBox();
            this.textBox6Input = new System.Windows.Forms.TextBox();
            this.textBox7Input = new System.Windows.Forms.TextBox();
            this.textBox9Input = new System.Windows.Forms.TextBox();
            this.textBox8InputB = new System.Windows.Forms.TextBox();
            this.textBox8InputA = new System.Windows.Forms.TextBox();
            this.textBox10InputB = new System.Windows.Forms.TextBox();
            this.textBox10InputA = new System.Windows.Forms.TextBox();
            this.textBox1ResultA = new System.Windows.Forms.TextBox();
            this.textBox2ResultA = new System.Windows.Forms.TextBox();
            this.textBox3ResultA = new System.Windows.Forms.TextBox();
            this.textBox4ResultA = new System.Windows.Forms.TextBox();
            this.textBox5ResultA = new System.Windows.Forms.TextBox();
            this.textBox6ResultA = new System.Windows.Forms.TextBox();
            this.textBox7ResultA = new System.Windows.Forms.TextBox();
            this.textBox8ResultA = new System.Windows.Forms.TextBox();
            this.textBox9ResultA = new System.Windows.Forms.TextBox();
            this.textBox10ResultA = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.setPassValuesButton = new System.Windows.Forms.Button();
            this.setFailValuesButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox10ResultB = new System.Windows.Forms.TextBox();
            this.textBox9ResultB = new System.Windows.Forms.TextBox();
            this.textBox8ResultB = new System.Windows.Forms.TextBox();
            this.textBox7ResultB = new System.Windows.Forms.TextBox();
            this.textBox6ResultB = new System.Windows.Forms.TextBox();
            this.textBox5ResultB = new System.Windows.Forms.TextBox();
            this.textBox4ResultB = new System.Windows.Forms.TextBox();
            this.textBox3ResultB = new System.Windows.Forms.TextBox();
            this.textBox2ResultB = new System.Windows.Forms.TextBox();
            this.textBox1ResultB = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1Input
            // 
            this.textBox1Input.Location = new System.Drawing.Point(178, 72);
            this.textBox1Input.Name = "textBox1Input";
            this.textBox1Input.Size = new System.Drawing.Size(125, 27);
            this.textBox1Input.TabIndex = 0;
            // 
            // textBox2Input
            // 
            this.textBox2Input.Location = new System.Drawing.Point(178, 105);
            this.textBox2Input.Name = "textBox2Input";
            this.textBox2Input.Size = new System.Drawing.Size(125, 27);
            this.textBox2Input.TabIndex = 1;
            // 
            // textBox3Input
            // 
            this.textBox3Input.Location = new System.Drawing.Point(178, 138);
            this.textBox3Input.Name = "textBox3Input";
            this.textBox3Input.Size = new System.Drawing.Size(125, 27);
            this.textBox3Input.TabIndex = 2;
            // 
            // textBox4Input
            // 
            this.textBox4Input.Location = new System.Drawing.Point(178, 171);
            this.textBox4Input.Name = "textBox4Input";
            this.textBox4Input.Size = new System.Drawing.Size(125, 27);
            this.textBox4Input.TabIndex = 3;
            // 
            // textBox5InputA
            // 
            this.textBox5InputA.Location = new System.Drawing.Point(178, 204);
            this.textBox5InputA.Name = "textBox5InputA";
            this.textBox5InputA.Size = new System.Drawing.Size(60, 27);
            this.textBox5InputA.TabIndex = 4;
            // 
            // textBox5InputB
            // 
            this.textBox5InputB.Location = new System.Drawing.Point(243, 204);
            this.textBox5InputB.Name = "textBox5InputB";
            this.textBox5InputB.Size = new System.Drawing.Size(60, 27);
            this.textBox5InputB.TabIndex = 5;
            // 
            // textBox6Input
            // 
            this.textBox6Input.Location = new System.Drawing.Point(178, 237);
            this.textBox6Input.Name = "textBox6Input";
            this.textBox6Input.Size = new System.Drawing.Size(125, 27);
            this.textBox6Input.TabIndex = 6;
            // 
            // textBox7Input
            // 
            this.textBox7Input.Location = new System.Drawing.Point(178, 270);
            this.textBox7Input.Name = "textBox7Input";
            this.textBox7Input.Size = new System.Drawing.Size(125, 27);
            this.textBox7Input.TabIndex = 7;
            // 
            // textBox9Input
            // 
            this.textBox9Input.Location = new System.Drawing.Point(178, 336);
            this.textBox9Input.Name = "textBox9Input";
            this.textBox9Input.Size = new System.Drawing.Size(125, 27);
            this.textBox9Input.TabIndex = 8;
            // 
            // textBox8InputB
            // 
            this.textBox8InputB.Location = new System.Drawing.Point(243, 303);
            this.textBox8InputB.Name = "textBox8InputB";
            this.textBox8InputB.Size = new System.Drawing.Size(60, 27);
            this.textBox8InputB.TabIndex = 10;
            // 
            // textBox8InputA
            // 
            this.textBox8InputA.Location = new System.Drawing.Point(178, 303);
            this.textBox8InputA.Name = "textBox8InputA";
            this.textBox8InputA.Size = new System.Drawing.Size(60, 27);
            this.textBox8InputA.TabIndex = 9;
            // 
            // textBox10InputB
            // 
            this.textBox10InputB.Location = new System.Drawing.Point(243, 369);
            this.textBox10InputB.Name = "textBox10InputB";
            this.textBox10InputB.Size = new System.Drawing.Size(60, 27);
            this.textBox10InputB.TabIndex = 12;
            // 
            // textBox10InputA
            // 
            this.textBox10InputA.Location = new System.Drawing.Point(178, 369);
            this.textBox10InputA.Name = "textBox10InputA";
            this.textBox10InputA.Size = new System.Drawing.Size(60, 27);
            this.textBox10InputA.TabIndex = 11;
            // 
            // textBox1ResultA
            // 
            this.textBox1ResultA.Location = new System.Drawing.Point(319, 72);
            this.textBox1ResultA.Name = "textBox1ResultA";
            this.textBox1ResultA.ReadOnly = true;
            this.textBox1ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox1ResultA.TabIndex = 13;
            this.textBox1ResultA.TabStop = false;
            // 
            // textBox2ResultA
            // 
            this.textBox2ResultA.Location = new System.Drawing.Point(319, 105);
            this.textBox2ResultA.Name = "textBox2ResultA";
            this.textBox2ResultA.ReadOnly = true;
            this.textBox2ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox2ResultA.TabIndex = 14;
            this.textBox2ResultA.TabStop = false;
            // 
            // textBox3ResultA
            // 
            this.textBox3ResultA.Location = new System.Drawing.Point(319, 138);
            this.textBox3ResultA.Name = "textBox3ResultA";
            this.textBox3ResultA.ReadOnly = true;
            this.textBox3ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox3ResultA.TabIndex = 15;
            this.textBox3ResultA.TabStop = false;
            // 
            // textBox4ResultA
            // 
            this.textBox4ResultA.Location = new System.Drawing.Point(319, 171);
            this.textBox4ResultA.Name = "textBox4ResultA";
            this.textBox4ResultA.ReadOnly = true;
            this.textBox4ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox4ResultA.TabIndex = 16;
            this.textBox4ResultA.TabStop = false;
            // 
            // textBox5ResultA
            // 
            this.textBox5ResultA.Location = new System.Drawing.Point(319, 204);
            this.textBox5ResultA.Name = "textBox5ResultA";
            this.textBox5ResultA.ReadOnly = true;
            this.textBox5ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox5ResultA.TabIndex = 17;
            this.textBox5ResultA.TabStop = false;
            // 
            // textBox6ResultA
            // 
            this.textBox6ResultA.Location = new System.Drawing.Point(319, 237);
            this.textBox6ResultA.Name = "textBox6ResultA";
            this.textBox6ResultA.ReadOnly = true;
            this.textBox6ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox6ResultA.TabIndex = 18;
            this.textBox6ResultA.TabStop = false;
            // 
            // textBox7ResultA
            // 
            this.textBox7ResultA.Location = new System.Drawing.Point(319, 270);
            this.textBox7ResultA.Name = "textBox7ResultA";
            this.textBox7ResultA.ReadOnly = true;
            this.textBox7ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox7ResultA.TabIndex = 19;
            this.textBox7ResultA.TabStop = false;
            // 
            // textBox8ResultA
            // 
            this.textBox8ResultA.Location = new System.Drawing.Point(319, 303);
            this.textBox8ResultA.Name = "textBox8ResultA";
            this.textBox8ResultA.ReadOnly = true;
            this.textBox8ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox8ResultA.TabIndex = 20;
            this.textBox8ResultA.TabStop = false;
            // 
            // textBox9ResultA
            // 
            this.textBox9ResultA.Location = new System.Drawing.Point(319, 336);
            this.textBox9ResultA.Name = "textBox9ResultA";
            this.textBox9ResultA.ReadOnly = true;
            this.textBox9ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox9ResultA.TabIndex = 21;
            this.textBox9ResultA.TabStop = false;
            // 
            // textBox10ResultA
            // 
            this.textBox10ResultA.Location = new System.Drawing.Point(319, 369);
            this.textBox10ResultA.Name = "textBox10ResultA";
            this.textBox10ResultA.ReadOnly = true;
            this.textBox10ResultA.Size = new System.Drawing.Size(100, 27);
            this.textBox10ResultA.TabIndex = 22;
            this.textBox10ResultA.TabStop = false;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(325, 418);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(94, 29);
            this.calculateButton.TabIndex = 23;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // setPassValuesButton
            // 
            this.setPassValuesButton.Location = new System.Drawing.Point(43, 418);
            this.setPassValuesButton.Name = "setPassValuesButton";
            this.setPassValuesButton.Size = new System.Drawing.Size(132, 29);
            this.setPassValuesButton.TabIndex = 24;
            this.setPassValuesButton.Text = "Set Pass Values";
            this.setPassValuesButton.UseVisualStyleBackColor = true;
            this.setPassValuesButton.Click += new System.EventHandler(this.setPassValuesButton_Click);
            // 
            // setFailValuesButton
            // 
            this.setFailValuesButton.Location = new System.Drawing.Point(181, 418);
            this.setFailValuesButton.Name = "setFailValuesButton";
            this.setFailValuesButton.Size = new System.Drawing.Size(138, 29);
            this.setFailValuesButton.TabIndex = 25;
            this.setFailValuesButton.Text = "Set Fail Values";
            this.setFailValuesButton.UseVisualStyleBackColor = true;
            this.setFailValuesButton.Click += new System.EventHandler(this.setFailValuesButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 26;
            this.label1.Text = "input == \"Frank\"";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 20);
            this.label2.TabIndex = 27;
            this.label2.Text = "input is empty";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 20);
            this.label3.TabIndex = 28;
            this.label3.Text = "input == 2.3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 29;
            this.label4.Text = "input is false";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "inputA == inputB";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "input != \"Jones\"";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 273);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "input > 0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 306);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "inputA < inputB";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 339);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 20);
            this.label9.TabIndex = 34;
            this.label9.Text = "input >= 500";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(43, 372);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 20);
            this.label10.TabIndex = 35;
            this.label10.Text = "inputA <= inputB";
            // 
            // textBox10ResultB
            // 
            this.textBox10ResultB.Location = new System.Drawing.Point(434, 369);
            this.textBox10ResultB.Name = "textBox10ResultB";
            this.textBox10ResultB.ReadOnly = true;
            this.textBox10ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox10ResultB.TabIndex = 45;
            this.textBox10ResultB.TabStop = false;
            // 
            // textBox9ResultB
            // 
            this.textBox9ResultB.Location = new System.Drawing.Point(434, 336);
            this.textBox9ResultB.Name = "textBox9ResultB";
            this.textBox9ResultB.ReadOnly = true;
            this.textBox9ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox9ResultB.TabIndex = 44;
            this.textBox9ResultB.TabStop = false;
            // 
            // textBox8ResultB
            // 
            this.textBox8ResultB.Location = new System.Drawing.Point(434, 303);
            this.textBox8ResultB.Name = "textBox8ResultB";
            this.textBox8ResultB.ReadOnly = true;
            this.textBox8ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox8ResultB.TabIndex = 43;
            this.textBox8ResultB.TabStop = false;
            // 
            // textBox7ResultB
            // 
            this.textBox7ResultB.Location = new System.Drawing.Point(434, 270);
            this.textBox7ResultB.Name = "textBox7ResultB";
            this.textBox7ResultB.ReadOnly = true;
            this.textBox7ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox7ResultB.TabIndex = 42;
            this.textBox7ResultB.TabStop = false;
            // 
            // textBox6ResultB
            // 
            this.textBox6ResultB.Location = new System.Drawing.Point(434, 237);
            this.textBox6ResultB.Name = "textBox6ResultB";
            this.textBox6ResultB.ReadOnly = true;
            this.textBox6ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox6ResultB.TabIndex = 41;
            this.textBox6ResultB.TabStop = false;
            // 
            // textBox5ResultB
            // 
            this.textBox5ResultB.Location = new System.Drawing.Point(434, 204);
            this.textBox5ResultB.Name = "textBox5ResultB";
            this.textBox5ResultB.ReadOnly = true;
            this.textBox5ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox5ResultB.TabIndex = 40;
            this.textBox5ResultB.TabStop = false;
            // 
            // textBox4ResultB
            // 
            this.textBox4ResultB.Location = new System.Drawing.Point(434, 171);
            this.textBox4ResultB.Name = "textBox4ResultB";
            this.textBox4ResultB.ReadOnly = true;
            this.textBox4ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox4ResultB.TabIndex = 39;
            this.textBox4ResultB.TabStop = false;
            // 
            // textBox3ResultB
            // 
            this.textBox3ResultB.Location = new System.Drawing.Point(434, 138);
            this.textBox3ResultB.Name = "textBox3ResultB";
            this.textBox3ResultB.ReadOnly = true;
            this.textBox3ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox3ResultB.TabIndex = 38;
            this.textBox3ResultB.TabStop = false;
            // 
            // textBox2ResultB
            // 
            this.textBox2ResultB.Location = new System.Drawing.Point(434, 105);
            this.textBox2ResultB.Name = "textBox2ResultB";
            this.textBox2ResultB.ReadOnly = true;
            this.textBox2ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox2ResultB.TabIndex = 37;
            this.textBox2ResultB.TabStop = false;
            // 
            // textBox1ResultB
            // 
            this.textBox1ResultB.Location = new System.Drawing.Point(434, 72);
            this.textBox1ResultB.Name = "textBox1ResultB";
            this.textBox1ResultB.ReadOnly = true;
            this.textBox1ResultB.Size = new System.Drawing.Size(100, 27);
            this.textBox1ResultB.TabIndex = 36;
            this.textBox1ResultB.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(335, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 20);
            this.label11.TabIndex = 46;
            this.label11.Text = "Result A";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(451, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 20);
            this.label12.TabIndex = 47;
            this.label12.Text = "Result B";
            // 
            // frmIfStatements
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 506);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox10ResultB);
            this.Controls.Add(this.textBox9ResultB);
            this.Controls.Add(this.textBox8ResultB);
            this.Controls.Add(this.textBox7ResultB);
            this.Controls.Add(this.textBox6ResultB);
            this.Controls.Add(this.textBox5ResultB);
            this.Controls.Add(this.textBox4ResultB);
            this.Controls.Add(this.textBox3ResultB);
            this.Controls.Add(this.textBox2ResultB);
            this.Controls.Add(this.textBox1ResultB);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.setFailValuesButton);
            this.Controls.Add(this.setPassValuesButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.textBox10ResultA);
            this.Controls.Add(this.textBox9ResultA);
            this.Controls.Add(this.textBox8ResultA);
            this.Controls.Add(this.textBox7ResultA);
            this.Controls.Add(this.textBox6ResultA);
            this.Controls.Add(this.textBox5ResultA);
            this.Controls.Add(this.textBox4ResultA);
            this.Controls.Add(this.textBox3ResultA);
            this.Controls.Add(this.textBox2ResultA);
            this.Controls.Add(this.textBox1ResultA);
            this.Controls.Add(this.textBox10InputB);
            this.Controls.Add(this.textBox10InputA);
            this.Controls.Add(this.textBox8InputB);
            this.Controls.Add(this.textBox8InputA);
            this.Controls.Add(this.textBox9Input);
            this.Controls.Add(this.textBox7Input);
            this.Controls.Add(this.textBox6Input);
            this.Controls.Add(this.textBox5InputB);
            this.Controls.Add(this.textBox5InputA);
            this.Controls.Add(this.textBox4Input);
            this.Controls.Add(this.textBox3Input);
            this.Controls.Add(this.textBox2Input);
            this.Controls.Add(this.textBox1Input);
            this.Name = "frmIfStatements";
            this.Text = "ex2d1: If Statements";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1Input;
        private System.Windows.Forms.TextBox textBox2Input;
        private System.Windows.Forms.TextBox textBox3Input;
        private System.Windows.Forms.TextBox textBox4Input;
        private System.Windows.Forms.TextBox textBox5InputA;
        private System.Windows.Forms.TextBox textBox5InputB;
        private System.Windows.Forms.TextBox textBox6Input;
        private System.Windows.Forms.TextBox textBox7Input;
        private System.Windows.Forms.TextBox textBox9Input;
        private System.Windows.Forms.TextBox textBox8InputB;
        private System.Windows.Forms.TextBox textBox8InputA;
        private System.Windows.Forms.TextBox textBox10InputB;
        private System.Windows.Forms.TextBox textBox10InputA;
        private System.Windows.Forms.TextBox textBox1ResultA;
        private System.Windows.Forms.TextBox textBox2ResultA;
        private System.Windows.Forms.TextBox textBox3ResultA;
        private System.Windows.Forms.TextBox textBox4ResultA;
        private System.Windows.Forms.TextBox textBox5ResultA;
        private System.Windows.Forms.TextBox textBox6ResultA;
        private System.Windows.Forms.TextBox textBox7ResultA;
        private System.Windows.Forms.TextBox textBox8ResultA;
        private System.Windows.Forms.TextBox textBox9ResultA;
        private System.Windows.Forms.TextBox textBox10ResultA;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button setPassValuesButton;
        private System.Windows.Forms.Button setFailValuesButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox10ResultB;
        private System.Windows.Forms.TextBox textBox9ResultB;
        private System.Windows.Forms.TextBox textBox8ResultB;
        private System.Windows.Forms.TextBox textBox7ResultB;
        private System.Windows.Forms.TextBox textBox6ResultB;
        private System.Windows.Forms.TextBox textBox5ResultB;
        private System.Windows.Forms.TextBox textBox4ResultB;
        private System.Windows.Forms.TextBox textBox3ResultB;
        private System.Windows.Forms.TextBox textBox2ResultB;
        private System.Windows.Forms.TextBox textBox1ResultB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}

