﻿
namespace ex2b1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTotalUSD = new System.Windows.Forms.TextBox();
            this.txtUSDNewZealand = new System.Windows.Forms.TextBox();
            this.txtUSDIndonesia = new System.Windows.Forms.TextBox();
            this.txtUSDEuro = new System.Windows.Forms.TextBox();
            this.txtUSDChile = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRateNewZealand = new System.Windows.Forms.TextBox();
            this.txtRateIndonesia = new System.Windows.Forms.TextBox();
            this.txtRateEuro = new System.Windows.Forms.TextBox();
            this.txtRateChile = new System.Windows.Forms.TextBox();
            this.txtAmountNewZealand = new System.Windows.Forms.TextBox();
            this.txtAmountIndonesia = new System.Windows.Forms.TextBox();
            this.txtAmountEuro = new System.Windows.Forms.TextBox();
            this.txtAmountChile = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(392, 331);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(161, 26);
            this.btnExit.TabIndex = 39;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(210, 328);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(161, 29);
            this.btnReset.TabIndex = 36;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(758, 275);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 28);
            this.label9.TabIndex = 55;
            this.label9.Text = "+";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(-72, 301);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 20);
            this.label8.TabIndex = 54;
            this.label8.Text = "$US";
            // 
            // txtTotalUSD
            // 
            this.txtTotalUSD.Location = new System.Drawing.Point(804, 279);
            this.txtTotalUSD.Name = "txtTotalUSD";
            this.txtTotalUSD.ReadOnly = true;
            this.txtTotalUSD.Size = new System.Drawing.Size(161, 27);
            this.txtTotalUSD.TabIndex = 53;
            this.txtTotalUSD.TabStop = false;
            this.txtTotalUSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtUSDNewZealand
            // 
            this.txtUSDNewZealand.Location = new System.Drawing.Point(577, 279);
            this.txtUSDNewZealand.Name = "txtUSDNewZealand";
            this.txtUSDNewZealand.ReadOnly = true;
            this.txtUSDNewZealand.Size = new System.Drawing.Size(161, 27);
            this.txtUSDNewZealand.TabIndex = 52;
            this.txtUSDNewZealand.TabStop = false;
            this.txtUSDNewZealand.Text = "0.00";
            this.txtUSDNewZealand.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtUSDIndonesia
            // 
            this.txtUSDIndonesia.Location = new System.Drawing.Point(392, 279);
            this.txtUSDIndonesia.Name = "txtUSDIndonesia";
            this.txtUSDIndonesia.ReadOnly = true;
            this.txtUSDIndonesia.Size = new System.Drawing.Size(161, 27);
            this.txtUSDIndonesia.TabIndex = 51;
            this.txtUSDIndonesia.TabStop = false;
            this.txtUSDIndonesia.Text = "0.00";
            this.txtUSDIndonesia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtUSDEuro
            // 
            this.txtUSDEuro.Location = new System.Drawing.Point(210, 279);
            this.txtUSDEuro.Name = "txtUSDEuro";
            this.txtUSDEuro.ReadOnly = true;
            this.txtUSDEuro.Size = new System.Drawing.Size(161, 27);
            this.txtUSDEuro.TabIndex = 50;
            this.txtUSDEuro.TabStop = false;
            this.txtUSDEuro.Text = "0.00";
            this.txtUSDEuro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtUSDChile
            // 
            this.txtUSDChile.Location = new System.Drawing.Point(32, 279);
            this.txtUSDChile.Name = "txtUSDChile";
            this.txtUSDChile.ReadOnly = true;
            this.txtUSDChile.Size = new System.Drawing.Size(156, 27);
            this.txtUSDChile.TabIndex = 49;
            this.txtUSDChile.TabStop = false;
            this.txtUSDChile.Text = "0.00";
            this.txtUSDChile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(-79, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 20);
            this.label7.TabIndex = 48;
            this.label7.Text = "Rate:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-102, 235);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 20);
            this.label6.TabIndex = 47;
            this.label6.Text = "Amount:";
            // 
            // txtRateNewZealand
            // 
            this.txtRateNewZealand.Location = new System.Drawing.Point(577, 246);
            this.txtRateNewZealand.Name = "txtRateNewZealand";
            this.txtRateNewZealand.Size = new System.Drawing.Size(161, 27);
            this.txtRateNewZealand.TabIndex = 46;
            this.txtRateNewZealand.Text = "0.61357518";
            this.txtRateNewZealand.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRateNewZealand.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtRateIndonesia
            // 
            this.txtRateIndonesia.Location = new System.Drawing.Point(392, 246);
            this.txtRateIndonesia.Name = "txtRateIndonesia";
            this.txtRateIndonesia.Size = new System.Drawing.Size(161, 27);
            this.txtRateIndonesia.TabIndex = 45;
            this.txtRateIndonesia.Text = "0.000067348327";
            this.txtRateIndonesia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRateIndonesia.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtRateEuro
            // 
            this.txtRateEuro.Location = new System.Drawing.Point(210, 246);
            this.txtRateEuro.Name = "txtRateEuro";
            this.txtRateEuro.Size = new System.Drawing.Size(161, 27);
            this.txtRateEuro.TabIndex = 42;
            this.txtRateEuro.Text = "1.002269";
            this.txtRateEuro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRateEuro.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtRateChile
            // 
            this.txtRateChile.Location = new System.Drawing.Point(32, 246);
            this.txtRateChile.Name = "txtRateChile";
            this.txtRateChile.Size = new System.Drawing.Size(156, 27);
            this.txtRateChile.TabIndex = 41;
            this.txtRateChile.Text = "0.0011279352";
            this.txtRateChile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRateChile.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtAmountNewZealand
            // 
            this.txtAmountNewZealand.Location = new System.Drawing.Point(577, 213);
            this.txtAmountNewZealand.Name = "txtAmountNewZealand";
            this.txtAmountNewZealand.Size = new System.Drawing.Size(161, 27);
            this.txtAmountNewZealand.TabIndex = 35;
            this.txtAmountNewZealand.Text = "0.00";
            this.txtAmountNewZealand.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAmountNewZealand.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtAmountIndonesia
            // 
            this.txtAmountIndonesia.Location = new System.Drawing.Point(392, 213);
            this.txtAmountIndonesia.Name = "txtAmountIndonesia";
            this.txtAmountIndonesia.Size = new System.Drawing.Size(161, 27);
            this.txtAmountIndonesia.TabIndex = 33;
            this.txtAmountIndonesia.Text = "0.00";
            this.txtAmountIndonesia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAmountIndonesia.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtAmountEuro
            // 
            this.txtAmountEuro.Location = new System.Drawing.Point(210, 213);
            this.txtAmountEuro.Name = "txtAmountEuro";
            this.txtAmountEuro.Size = new System.Drawing.Size(161, 27);
            this.txtAmountEuro.TabIndex = 31;
            this.txtAmountEuro.Text = "0.00";
            this.txtAmountEuro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAmountEuro.TextChanged += new System.EventHandler(this.calculate);
            // 
            // txtAmountChile
            // 
            this.txtAmountChile.Location = new System.Drawing.Point(32, 213);
            this.txtAmountChile.Name = "txtAmountChile";
            this.txtAmountChile.Size = new System.Drawing.Size(156, 27);
            this.txtAmountChile.TabIndex = 28;
            this.txtAmountChile.Text = "0.00";
            this.txtAmountChile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAmountChile.TextChanged += new System.EventHandler(this.calculate);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(848, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 20);
            this.label5.TabIndex = 44;
            this.label5.Text = "US Dollar";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(586, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 20);
            this.label4.TabIndex = 43;
            this.label4.Text = "New Zealand Dollar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(407, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 20);
            this.label3.TabIndex = 40;
            this.label3.Text = "Indonesian Rupiah";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 38;
            this.label2.Text = "Euro";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "Chilean Peso";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(804, 55);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(161, 121);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 34;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(577, 55);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(161, 121);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 32;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(392, 55);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(161, 121);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(210, 55);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(161, 121);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(32, 55);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(156, 121);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 407);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtTotalUSD);
            this.Controls.Add(this.txtUSDNewZealand);
            this.Controls.Add(this.txtUSDIndonesia);
            this.Controls.Add(this.txtUSDEuro);
            this.Controls.Add(this.txtUSDChile);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtRateNewZealand);
            this.Controls.Add(this.txtRateIndonesia);
            this.Controls.Add(this.txtRateEuro);
            this.Controls.Add(this.txtRateChile);
            this.Controls.Add(this.txtAmountNewZealand);
            this.Controls.Add(this.txtAmountIndonesia);
            this.Controls.Add(this.txtAmountEuro);
            this.Controls.Add(this.txtAmountChile);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "ex2b1: Currency Converter with Variables";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTotalUSD;
        private System.Windows.Forms.TextBox txtUSDNewZealand;
        private System.Windows.Forms.TextBox txtUSDIndonesia;
        private System.Windows.Forms.TextBox txtUSDEuro;
        private System.Windows.Forms.TextBox txtUSDChile;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtRateNewZealand;
        private System.Windows.Forms.TextBox txtRateIndonesia;
        private System.Windows.Forms.TextBox txtRateEuro;
        private System.Windows.Forms.TextBox txtRateChile;
        private System.Windows.Forms.TextBox txtAmountNewZealand;
        private System.Windows.Forms.TextBox txtAmountIndonesia;
        private System.Windows.Forms.TextBox txtAmountEuro;
        private System.Windows.Forms.TextBox txtAmountChile;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

