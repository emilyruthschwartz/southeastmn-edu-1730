﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ex1e
{
    public partial class frmAverageTestScore : Form
    {
        public frmAverageTestScore()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTestScore1.Text = "0";
            txtTestScore2.Text = "0";
            txtTestScore3.Text = "0";
            txtAverageScore.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            txtAverageScore.Text = (
                    (Convert.ToDecimal(txtTestScore1.Text) + Convert.ToDecimal(txtTestScore2.Text) + Convert.ToDecimal(txtTestScore3.Text)) / 3
                ).ToString("0.00");
        }
    }
}
