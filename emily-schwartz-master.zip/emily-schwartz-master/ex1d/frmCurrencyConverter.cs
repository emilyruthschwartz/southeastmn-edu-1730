﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ex1d
{
    public partial class frmCurrencyConverter : Form
    {
        public frmCurrencyConverter()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAmountChile.Text = "0.00";
            txtRateChile.Text = "0.0011279352";
            txtAmountEuro.Text = "0.00";
            txtRateEuro.Text = "1.002269";
            txtAmountIndonesia.Text = "0.00";
            txtRateIndonesia.Text = "0.000067348327";
            txtAmountNewZealand.Text = "0.00";
            txtRateNewZealand.Text = "0.61357518";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chileTextChanged(object sender, EventArgs e)
        {
            txtUSDChile.Text = (
                    Convert.ToDecimal(txtAmountChile.Text) * Convert.ToDecimal(txtRateChile.Text)
                ).ToString("0.00");
        }

        private void euroTextChanged(object sender, EventArgs e)
        {
            txtUSDEuro.Text = (
                    Convert.ToDecimal(txtAmountEuro.Text) * Convert.ToDecimal(txtRateEuro.Text)
                ).ToString("0.00");
        }

        private void indonesiaTextChanged(object sender, EventArgs e)
        {
            txtUSDIndonesia.Text = (
                    Convert.ToDecimal(txtAmountIndonesia.Text) * Convert.ToDecimal(txtRateIndonesia.Text)
                ).ToString("0.00");
        }

        private void newzealandTextChanged(object sender, EventArgs e)
        {
            txtUSDNewZealand.Text = (
                   Convert.ToDecimal(txtAmountNewZealand.Text) * Convert.ToDecimal(txtRateNewZealand.Text)
               ).ToString("0.00");
        }

        private void usdTextChanged(object sender, EventArgs e)
        {
            txtTotalUSD.Text = (
                    Convert.ToDecimal(txtUSDChile.Text) + Convert.ToDecimal(txtUSDEuro.Text) + Convert.ToDecimal(txtUSDIndonesia.Text) + Convert.ToDecimal(txtUSDNewZealand.Text)
                ).ToString("0.00");
        }
    }
}
