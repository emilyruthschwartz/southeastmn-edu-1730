﻿
namespace ex2f1
{
    partial class frmIfStatements
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.input1aTextBox = new System.Windows.Forms.TextBox();
            this.input2aTextBox = new System.Windows.Forms.TextBox();
            this.input3aTextBox = new System.Windows.Forms.TextBox();
            this.input4aTextBox = new System.Windows.Forms.TextBox();
            this.input5aTextBox = new System.Windows.Forms.TextBox();
            this.input6aTextBox = new System.Windows.Forms.TextBox();
            this.input6bTextBox = new System.Windows.Forms.TextBox();
            this.result6TextBox = new System.Windows.Forms.TextBox();
            this.result5TextBox = new System.Windows.Forms.TextBox();
            this.result4TextBox = new System.Windows.Forms.TextBox();
            this.result3TextBox = new System.Windows.Forms.TextBox();
            this.result2TextBox = new System.Windows.Forms.TextBox();
            this.result1TextBox = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.input7aTextBox = new System.Windows.Forms.TextBox();
            this.input8aTextBox = new System.Windows.Forms.TextBox();
            this.input8bTextBox = new System.Windows.Forms.TextBox();
            this.input9aTextBox = new System.Windows.Forms.TextBox();
            this.input9bTextBox = new System.Windows.Forms.TextBox();
            this.input10bTextBox = new System.Windows.Forms.TextBox();
            this.input10aTextBox = new System.Windows.Forms.TextBox();
            this.result7TextBox = new System.Windows.Forms.TextBox();
            this.result8TextBox = new System.Windows.Forms.TextBox();
            this.result9TextBox = new System.Windows.Forms.TextBox();
            this.result10TextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "1) if";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "2) if {block}";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "3) if else";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "4) if else if";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "5) Better range test";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "6) Nested if else";
            // 
            // input1aTextBox
            // 
            this.input1aTextBox.Location = new System.Drawing.Point(212, 26);
            this.input1aTextBox.Name = "input1aTextBox";
            this.input1aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input1aTextBox.TabIndex = 6;
            this.input1aTextBox.Text = "100.00";
            this.input1aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input2aTextBox
            // 
            this.input2aTextBox.Location = new System.Drawing.Point(212, 58);
            this.input2aTextBox.Name = "input2aTextBox";
            this.input2aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input2aTextBox.TabIndex = 7;
            this.input2aTextBox.Text = "100.00";
            this.input2aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input3aTextBox
            // 
            this.input3aTextBox.Location = new System.Drawing.Point(212, 89);
            this.input3aTextBox.Name = "input3aTextBox";
            this.input3aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input3aTextBox.TabIndex = 8;
            this.input3aTextBox.Text = "100.00";
            this.input3aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input4aTextBox
            // 
            this.input4aTextBox.Location = new System.Drawing.Point(212, 120);
            this.input4aTextBox.Name = "input4aTextBox";
            this.input4aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input4aTextBox.TabIndex = 9;
            this.input4aTextBox.Text = "100.00";
            this.input4aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input5aTextBox
            // 
            this.input5aTextBox.Location = new System.Drawing.Point(212, 151);
            this.input5aTextBox.Name = "input5aTextBox";
            this.input5aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input5aTextBox.TabIndex = 10;
            this.input5aTextBox.Text = "100.00";
            this.input5aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input6aTextBox
            // 
            this.input6aTextBox.Location = new System.Drawing.Point(212, 182);
            this.input6aTextBox.Name = "input6aTextBox";
            this.input6aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input6aTextBox.TabIndex = 11;
            this.input6aTextBox.Text = "100.00";
            this.input6aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input6bTextBox
            // 
            this.input6bTextBox.Location = new System.Drawing.Point(327, 182);
            this.input6bTextBox.Name = "input6bTextBox";
            this.input6bTextBox.Size = new System.Drawing.Size(37, 22);
            this.input6bTextBox.TabIndex = 12;
            this.input6bTextBox.Text = "R";
            // 
            // result6TextBox
            // 
            this.result6TextBox.Location = new System.Drawing.Point(384, 182);
            this.result6TextBox.Name = "result6TextBox";
            this.result6TextBox.ReadOnly = true;
            this.result6TextBox.Size = new System.Drawing.Size(171, 22);
            this.result6TextBox.TabIndex = 13;
            this.result6TextBox.TabStop = false;
            this.result6TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result5TextBox
            // 
            this.result5TextBox.Location = new System.Drawing.Point(384, 151);
            this.result5TextBox.Name = "result5TextBox";
            this.result5TextBox.ReadOnly = true;
            this.result5TextBox.Size = new System.Drawing.Size(171, 22);
            this.result5TextBox.TabIndex = 14;
            this.result5TextBox.TabStop = false;
            this.result5TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result4TextBox
            // 
            this.result4TextBox.Location = new System.Drawing.Point(384, 120);
            this.result4TextBox.Name = "result4TextBox";
            this.result4TextBox.ReadOnly = true;
            this.result4TextBox.Size = new System.Drawing.Size(171, 22);
            this.result4TextBox.TabIndex = 15;
            this.result4TextBox.TabStop = false;
            this.result4TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result3TextBox
            // 
            this.result3TextBox.Location = new System.Drawing.Point(384, 89);
            this.result3TextBox.Name = "result3TextBox";
            this.result3TextBox.ReadOnly = true;
            this.result3TextBox.Size = new System.Drawing.Size(171, 22);
            this.result3TextBox.TabIndex = 16;
            this.result3TextBox.TabStop = false;
            this.result3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result2TextBox
            // 
            this.result2TextBox.Location = new System.Drawing.Point(384, 58);
            this.result2TextBox.Name = "result2TextBox";
            this.result2TextBox.ReadOnly = true;
            this.result2TextBox.Size = new System.Drawing.Size(171, 22);
            this.result2TextBox.TabIndex = 17;
            this.result2TextBox.TabStop = false;
            this.result2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result1TextBox
            // 
            this.result1TextBox.Location = new System.Drawing.Point(384, 27);
            this.result1TextBox.Name = "result1TextBox";
            this.result1TextBox.ReadOnly = true;
            this.result1TextBox.Size = new System.Drawing.Size(171, 22);
            this.result1TextBox.TabIndex = 18;
            this.result1TextBox.TabStop = false;
            this.result1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(264, 332);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(100, 23);
            this.btnCalc.TabIndex = 19;
            this.btnCalc.Text = "Calculate";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 17);
            this.label7.TabIndex = 20;
            this.label7.Text = "7) Validate input";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 243);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 17);
            this.label8.TabIndex = 21;
            this.label8.Text = "8) Price * quant, ship";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(39, 271);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 17);
            this.label9.TabIndex = 22;
            this.label9.Text = "9) Difference * rate";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(39, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 17);
            this.label10.TabIndex = 23;
            this.label10.Text = "10) Divide large";
            // 
            // input7aTextBox
            // 
            this.input7aTextBox.Location = new System.Drawing.Point(212, 212);
            this.input7aTextBox.Name = "input7aTextBox";
            this.input7aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input7aTextBox.TabIndex = 24;
            this.input7aTextBox.Text = "100.00";
            this.input7aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input8aTextBox
            // 
            this.input8aTextBox.Location = new System.Drawing.Point(212, 238);
            this.input8aTextBox.Name = "input8aTextBox";
            this.input8aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input8aTextBox.TabIndex = 25;
            this.input8aTextBox.Text = "25.00";
            this.input8aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input8bTextBox
            // 
            this.input8bTextBox.Location = new System.Drawing.Point(327, 238);
            this.input8bTextBox.Name = "input8bTextBox";
            this.input8bTextBox.Size = new System.Drawing.Size(37, 22);
            this.input8bTextBox.TabIndex = 26;
            this.input8bTextBox.Text = "2";
            // 
            // input9aTextBox
            // 
            this.input9aTextBox.Location = new System.Drawing.Point(212, 266);
            this.input9aTextBox.Name = "input9aTextBox";
            this.input9aTextBox.Size = new System.Drawing.Size(77, 22);
            this.input9aTextBox.TabIndex = 27;
            this.input9aTextBox.Text = "10000";
            this.input9aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input9bTextBox
            // 
            this.input9bTextBox.Location = new System.Drawing.Point(295, 266);
            this.input9bTextBox.Name = "input9bTextBox";
            this.input9bTextBox.Size = new System.Drawing.Size(69, 22);
            this.input9bTextBox.TabIndex = 28;
            this.input9bTextBox.Text = "11000";
            this.input9bTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input10bTextBox
            // 
            this.input10bTextBox.Location = new System.Drawing.Point(295, 294);
            this.input10bTextBox.Name = "input10bTextBox";
            this.input10bTextBox.Size = new System.Drawing.Size(69, 22);
            this.input10bTextBox.TabIndex = 30;
            this.input10bTextBox.Text = "2";
            this.input10bTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // input10aTextBox
            // 
            this.input10aTextBox.Location = new System.Drawing.Point(212, 294);
            this.input10aTextBox.Name = "input10aTextBox";
            this.input10aTextBox.Size = new System.Drawing.Size(77, 22);
            this.input10aTextBox.TabIndex = 29;
            this.input10aTextBox.Text = "1";
            this.input10aTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result7TextBox
            // 
            this.result7TextBox.Location = new System.Drawing.Point(384, 212);
            this.result7TextBox.Name = "result7TextBox";
            this.result7TextBox.ReadOnly = true;
            this.result7TextBox.Size = new System.Drawing.Size(171, 22);
            this.result7TextBox.TabIndex = 34;
            this.result7TextBox.TabStop = false;
            this.result7TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result8TextBox
            // 
            this.result8TextBox.Location = new System.Drawing.Point(384, 238);
            this.result8TextBox.Name = "result8TextBox";
            this.result8TextBox.ReadOnly = true;
            this.result8TextBox.Size = new System.Drawing.Size(171, 22);
            this.result8TextBox.TabIndex = 33;
            this.result8TextBox.TabStop = false;
            this.result8TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result9TextBox
            // 
            this.result9TextBox.Location = new System.Drawing.Point(384, 268);
            this.result9TextBox.Name = "result9TextBox";
            this.result9TextBox.ReadOnly = true;
            this.result9TextBox.Size = new System.Drawing.Size(171, 22);
            this.result9TextBox.TabIndex = 32;
            this.result9TextBox.TabStop = false;
            this.result9TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // result10TextBox
            // 
            this.result10TextBox.Location = new System.Drawing.Point(384, 296);
            this.result10TextBox.Name = "result10TextBox";
            this.result10TextBox.ReadOnly = true;
            this.result10TextBox.Size = new System.Drawing.Size(171, 22);
            this.result10TextBox.TabIndex = 31;
            this.result10TextBox.TabStop = false;
            this.result10TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // frmIfStatements
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 370);
            this.Controls.Add(this.result7TextBox);
            this.Controls.Add(this.result8TextBox);
            this.Controls.Add(this.result9TextBox);
            this.Controls.Add(this.result10TextBox);
            this.Controls.Add(this.input10bTextBox);
            this.Controls.Add(this.input10aTextBox);
            this.Controls.Add(this.input9bTextBox);
            this.Controls.Add(this.input9aTextBox);
            this.Controls.Add(this.input8bTextBox);
            this.Controls.Add(this.input8aTextBox);
            this.Controls.Add(this.input7aTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.result1TextBox);
            this.Controls.Add(this.result2TextBox);
            this.Controls.Add(this.result3TextBox);
            this.Controls.Add(this.result4TextBox);
            this.Controls.Add(this.result5TextBox);
            this.Controls.Add(this.result6TextBox);
            this.Controls.Add(this.input6bTextBox);
            this.Controls.Add(this.input6aTextBox);
            this.Controls.Add(this.input5aTextBox);
            this.Controls.Add(this.input4aTextBox);
            this.Controls.Add(this.input3aTextBox);
            this.Controls.Add(this.input2aTextBox);
            this.Controls.Add(this.input1aTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmIfStatements";
            this.Text = "ex2f1: If Statements";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox input1aTextBox;
        private System.Windows.Forms.TextBox input2aTextBox;
        private System.Windows.Forms.TextBox input3aTextBox;
        private System.Windows.Forms.TextBox input4aTextBox;
        private System.Windows.Forms.TextBox input5aTextBox;
        private System.Windows.Forms.TextBox input6aTextBox;
        private System.Windows.Forms.TextBox input6bTextBox;
        private System.Windows.Forms.TextBox result6TextBox;
        private System.Windows.Forms.TextBox result5TextBox;
        private System.Windows.Forms.TextBox result4TextBox;
        private System.Windows.Forms.TextBox result3TextBox;
        private System.Windows.Forms.TextBox result2TextBox;
        private System.Windows.Forms.TextBox result1TextBox;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox input7aTextBox;
        private System.Windows.Forms.TextBox input8aTextBox;
        private System.Windows.Forms.TextBox input8bTextBox;
        private System.Windows.Forms.TextBox input9aTextBox;
        private System.Windows.Forms.TextBox input9bTextBox;
        private System.Windows.Forms.TextBox input10bTextBox;
        private System.Windows.Forms.TextBox input10aTextBox;
        private System.Windows.Forms.TextBox result7TextBox;
        private System.Windows.Forms.TextBox result8TextBox;
        private System.Windows.Forms.TextBox result9TextBox;
        private System.Windows.Forms.TextBox result10TextBox;
    }
}

