﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ex2f1
{
    public partial class frmIfStatements : Form
    {
        public frmIfStatements()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            // #1: if
            result1TextBox.Text = Ex2fCalculations.Calc01(input1aTextBox.Text);

            // #2: if {block}
            result2TextBox.Text = Ex2fCalculations.Calc02(input2aTextBox.Text);

            // #3: if else
            result3TextBox.Text = Ex2fCalculations.Calc03(input3aTextBox.Text);

            // #4: if else if
            result4TextBox.Text = Ex2fCalculations.Calc04(input4aTextBox.Text);

            // #5: Better range test
            result5TextBox.Text = Ex2fCalculations.Calc05(input5aTextBox.Text);

            // #6: Nested if statement
            result6TextBox.Text = Ex2fCalculations.Calc06(input6aTextBox.Text, input6bTextBox.Text);

            // #7: input validation
            result7TextBox.Text = Ex2fCalculations.Calc07(input7aTextBox.Text);

            // #8:  input validation, calculate total and shipping
            //      shipping = $5.00 for orders under $50.00
            result8TextBox.Text = Ex2fCalculations.Calc08(input8aTextBox.Text, input8bTextBox.Text);

            // #9: input validation, result = 0.1 * difference
            result9TextBox.Text = Ex2fCalculations.Calc09(input9aTextBox.Text, input9bTextBox.Text);

            // #10: Validate input, divide large num by small
            //      Both numbers must be > 0
            result10TextBox.Text = Ex2fCalculations.Calc10(input10aTextBox.Text, input10bTextBox.Text);
        }
    }
}
