﻿
namespace ex2e1NF
{
    partial class frmTests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.input01aTextBox = new System.Windows.Forms.TextBox();
            this.input02aTextBox = new System.Windows.Forms.TextBox();
            this.input03aTextBox = new System.Windows.Forms.TextBox();
            this.input03bTextBox = new System.Windows.Forms.TextBox();
            this.input03cTextBox = new System.Windows.Forms.TextBox();
            this.input07cTextBox = new System.Windows.Forms.TextBox();
            this.input07bTextBox = new System.Windows.Forms.TextBox();
            this.input07aTextBox = new System.Windows.Forms.TextBox();
            this.input07dTextBox = new System.Windows.Forms.TextBox();
            this.input08dTextBox = new System.Windows.Forms.TextBox();
            this.input08cTextBox = new System.Windows.Forms.TextBox();
            this.input08bTextBox = new System.Windows.Forms.TextBox();
            this.input08aTextBox = new System.Windows.Forms.TextBox();
            this.input08eTextBox = new System.Windows.Forms.TextBox();
            this.input09bTextBox = new System.Windows.Forms.TextBox();
            this.input09aTextBox = new System.Windows.Forms.TextBox();
            this.input10dTextBox = new System.Windows.Forms.TextBox();
            this.input10cTextBox = new System.Windows.Forms.TextBox();
            this.input10bTextBox = new System.Windows.Forms.TextBox();
            this.input10aTextBox = new System.Windows.Forms.TextBox();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.result08TextBox = new System.Windows.Forms.TextBox();
            this.result09aTextBox = new System.Windows.Forms.TextBox();
            this.result10TextBox = new System.Windows.Forms.TextBox();
            this.result09bTextBox = new System.Windows.Forms.TextBox();
            this.result07TextBox = new System.Windows.Forms.TextBox();
            this.result06bTextBox = new System.Windows.Forms.TextBox();
            this.result06aTextBox = new System.Windows.Forms.TextBox();
            this.result05bTextBox = new System.Windows.Forms.TextBox();
            this.result05aTextBox = new System.Windows.Forms.TextBox();
            this.result04bTextBox = new System.Windows.Forms.TextBox();
            this.result04aTextBox = new System.Windows.Forms.TextBox();
            this.result03bTextBox = new System.Windows.Forms.TextBox();
            this.result03aTextBox = new System.Windows.Forms.TextBox();
            this.result02aTextBox = new System.Windows.Forms.TextBox();
            this.result01TextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.result11TextBox = new System.Windows.Forms.TextBox();
            this.input11cTextBox = new System.Windows.Forms.TextBox();
            this.input11bTextBox = new System.Windows.Forms.TextBox();
            this.input11aTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.result12TextBox = new System.Windows.Forms.TextBox();
            this.input12cTextBox = new System.Windows.Forms.TextBox();
            this.input12bTextBox = new System.Windows.Forms.TextBox();
            this.input12aTextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.result13TextBox = new System.Windows.Forms.TextBox();
            this.input13bTextBox = new System.Windows.Forms.TextBox();
            this.input13aTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "01:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "02:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "03:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "04:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "05:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 214);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "06:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "07:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 276);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "08:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 309);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "09:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 342);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 17);
            this.label10.TabIndex = 9;
            this.label10.Text = "10:";
            // 
            // input01aTextBox
            // 
            this.input01aTextBox.Location = new System.Drawing.Point(74, 48);
            this.input01aTextBox.Name = "input01aTextBox";
            this.input01aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input01aTextBox.TabIndex = 10;
            this.input01aTextBox.Text = "250";
            // 
            // input02aTextBox
            // 
            this.input02aTextBox.Location = new System.Drawing.Point(74, 79);
            this.input02aTextBox.Name = "input02aTextBox";
            this.input02aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input02aTextBox.TabIndex = 11;
            this.input02aTextBox.Text = "4";
            // 
            // input03aTextBox
            // 
            this.input03aTextBox.Location = new System.Drawing.Point(74, 113);
            this.input03aTextBox.Name = "input03aTextBox";
            this.input03aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input03aTextBox.TabIndex = 12;
            this.input03aTextBox.Text = "true";
            // 
            // input03bTextBox
            // 
            this.input03bTextBox.Location = new System.Drawing.Point(174, 113);
            this.input03bTextBox.Name = "input03bTextBox";
            this.input03bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input03bTextBox.TabIndex = 13;
            this.input03bTextBox.Text = "0";
            // 
            // input03cTextBox
            // 
            this.input03cTextBox.Location = new System.Drawing.Point(274, 113);
            this.input03cTextBox.Name = "input03cTextBox";
            this.input03cTextBox.Size = new System.Drawing.Size(94, 22);
            this.input03cTextBox.TabIndex = 14;
            this.input03cTextBox.Text = "4";
            // 
            // input07cTextBox
            // 
            this.input07cTextBox.Location = new System.Drawing.Point(274, 242);
            this.input07cTextBox.Name = "input07cTextBox";
            this.input07cTextBox.Size = new System.Drawing.Size(94, 22);
            this.input07cTextBox.TabIndex = 17;
            this.input07cTextBox.Text = "1/9/2019";
            // 
            // input07bTextBox
            // 
            this.input07bTextBox.Location = new System.Drawing.Point(174, 242);
            this.input07bTextBox.Name = "input07bTextBox";
            this.input07bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input07bTextBox.TabIndex = 16;
            this.input07bTextBox.Text = "2/1/2019";
            // 
            // input07aTextBox
            // 
            this.input07aTextBox.Location = new System.Drawing.Point(74, 242);
            this.input07aTextBox.Name = "input07aTextBox";
            this.input07aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input07aTextBox.TabIndex = 15;
            this.input07aTextBox.Text = "1/1/2019";
            // 
            // input07dTextBox
            // 
            this.input07dTextBox.Location = new System.Drawing.Point(374, 242);
            this.input07dTextBox.Name = "input07dTextBox";
            this.input07dTextBox.Size = new System.Drawing.Size(94, 22);
            this.input07dTextBox.TabIndex = 18;
            this.input07dTextBox.Text = "true";
            // 
            // input08dTextBox
            // 
            this.input08dTextBox.Location = new System.Drawing.Point(374, 273);
            this.input08dTextBox.Name = "input08dTextBox";
            this.input08dTextBox.Size = new System.Drawing.Size(94, 22);
            this.input08dTextBox.TabIndex = 22;
            this.input08dTextBox.Text = "2018";
            // 
            // input08cTextBox
            // 
            this.input08cTextBox.Location = new System.Drawing.Point(274, 273);
            this.input08cTextBox.Name = "input08cTextBox";
            this.input08cTextBox.Size = new System.Drawing.Size(94, 22);
            this.input08cTextBox.TabIndex = 21;
            this.input08cTextBox.Text = "Part time";
            // 
            // input08bTextBox
            // 
            this.input08bTextBox.Location = new System.Drawing.Point(174, 273);
            this.input08bTextBox.Name = "input08bTextBox";
            this.input08bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input08bTextBox.TabIndex = 20;
            this.input08bTextBox.Text = "1000";
            // 
            // input08aTextBox
            // 
            this.input08aTextBox.Location = new System.Drawing.Point(74, 273);
            this.input08aTextBox.Name = "input08aTextBox";
            this.input08aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input08aTextBox.TabIndex = 19;
            this.input08aTextBox.Text = "1001";
            // 
            // input08eTextBox
            // 
            this.input08eTextBox.Location = new System.Drawing.Point(474, 273);
            this.input08eTextBox.Name = "input08eTextBox";
            this.input08eTextBox.Size = new System.Drawing.Size(94, 22);
            this.input08eTextBox.TabIndex = 26;
            this.input08eTextBox.Text = "2019";
            // 
            // input09bTextBox
            // 
            this.input09bTextBox.Location = new System.Drawing.Point(174, 306);
            this.input09bTextBox.Name = "input09bTextBox";
            this.input09bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input09bTextBox.TabIndex = 24;
            this.input09bTextBox.Text = "4";
            // 
            // input09aTextBox
            // 
            this.input09aTextBox.Location = new System.Drawing.Point(74, 306);
            this.input09aTextBox.Name = "input09aTextBox";
            this.input09aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input09aTextBox.TabIndex = 23;
            this.input09aTextBox.Text = "0";
            // 
            // input10dTextBox
            // 
            this.input10dTextBox.Location = new System.Drawing.Point(374, 339);
            this.input10dTextBox.Name = "input10dTextBox";
            this.input10dTextBox.Size = new System.Drawing.Size(94, 22);
            this.input10dTextBox.TabIndex = 30;
            this.input10dTextBox.Text = "4";
            // 
            // input10cTextBox
            // 
            this.input10cTextBox.Location = new System.Drawing.Point(274, 339);
            this.input10cTextBox.Name = "input10cTextBox";
            this.input10cTextBox.Size = new System.Drawing.Size(94, 22);
            this.input10cTextBox.TabIndex = 29;
            this.input10cTextBox.Text = "3";
            // 
            // input10bTextBox
            // 
            this.input10bTextBox.Location = new System.Drawing.Point(174, 339);
            this.input10bTextBox.Name = "input10bTextBox";
            this.input10bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input10bTextBox.TabIndex = 28;
            this.input10bTextBox.Text = "2";
            // 
            // input10aTextBox
            // 
            this.input10aTextBox.Location = new System.Drawing.Point(74, 339);
            this.input10aTextBox.Name = "input10aTextBox";
            this.input10aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input10aTextBox.TabIndex = 27;
            this.input10aTextBox.Text = "1";
            // 
            // buttonCalc
            // 
            this.buttonCalc.Location = new System.Drawing.Point(372, 496);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(96, 23);
            this.buttonCalc.TabIndex = 31;
            this.buttonCalc.Text = "Calculate";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // result08TextBox
            // 
            this.result08TextBox.Location = new System.Drawing.Point(574, 273);
            this.result08TextBox.Name = "result08TextBox";
            this.result08TextBox.ReadOnly = true;
            this.result08TextBox.Size = new System.Drawing.Size(94, 22);
            this.result08TextBox.TabIndex = 32;
            this.result08TextBox.TabStop = false;
            // 
            // result09aTextBox
            // 
            this.result09aTextBox.Location = new System.Drawing.Point(574, 306);
            this.result09aTextBox.Name = "result09aTextBox";
            this.result09aTextBox.ReadOnly = true;
            this.result09aTextBox.Size = new System.Drawing.Size(94, 22);
            this.result09aTextBox.TabIndex = 33;
            this.result09aTextBox.TabStop = false;
            // 
            // result10TextBox
            // 
            this.result10TextBox.Location = new System.Drawing.Point(574, 339);
            this.result10TextBox.Name = "result10TextBox";
            this.result10TextBox.ReadOnly = true;
            this.result10TextBox.Size = new System.Drawing.Size(94, 22);
            this.result10TextBox.TabIndex = 34;
            this.result10TextBox.TabStop = false;
            // 
            // result09bTextBox
            // 
            this.result09bTextBox.Location = new System.Drawing.Point(684, 306);
            this.result09bTextBox.Name = "result09bTextBox";
            this.result09bTextBox.ReadOnly = true;
            this.result09bTextBox.Size = new System.Drawing.Size(94, 22);
            this.result09bTextBox.TabIndex = 35;
            this.result09bTextBox.TabStop = false;
            // 
            // result07TextBox
            // 
            this.result07TextBox.Location = new System.Drawing.Point(574, 242);
            this.result07TextBox.Name = "result07TextBox";
            this.result07TextBox.ReadOnly = true;
            this.result07TextBox.Size = new System.Drawing.Size(94, 22);
            this.result07TextBox.TabIndex = 36;
            this.result07TextBox.TabStop = false;
            // 
            // result06bTextBox
            // 
            this.result06bTextBox.Location = new System.Drawing.Point(684, 211);
            this.result06bTextBox.Name = "result06bTextBox";
            this.result06bTextBox.ReadOnly = true;
            this.result06bTextBox.Size = new System.Drawing.Size(94, 22);
            this.result06bTextBox.TabIndex = 39;
            this.result06bTextBox.TabStop = false;
            // 
            // result06aTextBox
            // 
            this.result06aTextBox.Location = new System.Drawing.Point(574, 211);
            this.result06aTextBox.Name = "result06aTextBox";
            this.result06aTextBox.ReadOnly = true;
            this.result06aTextBox.Size = new System.Drawing.Size(94, 22);
            this.result06aTextBox.TabIndex = 38;
            this.result06aTextBox.TabStop = false;
            // 
            // result05bTextBox
            // 
            this.result05bTextBox.Location = new System.Drawing.Point(684, 178);
            this.result05bTextBox.Name = "result05bTextBox";
            this.result05bTextBox.ReadOnly = true;
            this.result05bTextBox.Size = new System.Drawing.Size(94, 22);
            this.result05bTextBox.TabIndex = 41;
            this.result05bTextBox.TabStop = false;
            // 
            // result05aTextBox
            // 
            this.result05aTextBox.Location = new System.Drawing.Point(574, 178);
            this.result05aTextBox.Name = "result05aTextBox";
            this.result05aTextBox.ReadOnly = true;
            this.result05aTextBox.Size = new System.Drawing.Size(94, 22);
            this.result05aTextBox.TabIndex = 40;
            this.result05aTextBox.TabStop = false;
            // 
            // result04bTextBox
            // 
            this.result04bTextBox.Location = new System.Drawing.Point(684, 147);
            this.result04bTextBox.Name = "result04bTextBox";
            this.result04bTextBox.ReadOnly = true;
            this.result04bTextBox.Size = new System.Drawing.Size(94, 22);
            this.result04bTextBox.TabIndex = 43;
            this.result04bTextBox.TabStop = false;
            // 
            // result04aTextBox
            // 
            this.result04aTextBox.Location = new System.Drawing.Point(574, 147);
            this.result04aTextBox.Name = "result04aTextBox";
            this.result04aTextBox.ReadOnly = true;
            this.result04aTextBox.Size = new System.Drawing.Size(94, 22);
            this.result04aTextBox.TabIndex = 42;
            this.result04aTextBox.TabStop = false;
            // 
            // result03bTextBox
            // 
            this.result03bTextBox.Location = new System.Drawing.Point(684, 113);
            this.result03bTextBox.Name = "result03bTextBox";
            this.result03bTextBox.ReadOnly = true;
            this.result03bTextBox.Size = new System.Drawing.Size(94, 22);
            this.result03bTextBox.TabIndex = 45;
            this.result03bTextBox.TabStop = false;
            // 
            // result03aTextBox
            // 
            this.result03aTextBox.Location = new System.Drawing.Point(574, 113);
            this.result03aTextBox.Name = "result03aTextBox";
            this.result03aTextBox.ReadOnly = true;
            this.result03aTextBox.Size = new System.Drawing.Size(94, 22);
            this.result03aTextBox.TabIndex = 44;
            this.result03aTextBox.TabStop = false;
            // 
            // result02aTextBox
            // 
            this.result02aTextBox.Location = new System.Drawing.Point(574, 79);
            this.result02aTextBox.Name = "result02aTextBox";
            this.result02aTextBox.ReadOnly = true;
            this.result02aTextBox.Size = new System.Drawing.Size(94, 22);
            this.result02aTextBox.TabIndex = 46;
            this.result02aTextBox.TabStop = false;
            // 
            // result01TextBox
            // 
            this.result01TextBox.Location = new System.Drawing.Point(574, 48);
            this.result01TextBox.Name = "result01TextBox";
            this.result01TextBox.ReadOnly = true;
            this.result01TextBox.Size = new System.Drawing.Size(94, 22);
            this.result01TextBox.TabIndex = 47;
            this.result01TextBox.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(595, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 17);
            this.label11.TabIndex = 48;
            this.label11.Text = "Result";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(690, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 17);
            this.label12.TabIndex = 49;
            this.label12.Text = "Side effect";
            // 
            // result11TextBox
            // 
            this.result11TextBox.Location = new System.Drawing.Point(574, 374);
            this.result11TextBox.Name = "result11TextBox";
            this.result11TextBox.ReadOnly = true;
            this.result11TextBox.Size = new System.Drawing.Size(94, 22);
            this.result11TextBox.TabIndex = 54;
            this.result11TextBox.TabStop = false;
            // 
            // input11cTextBox
            // 
            this.input11cTextBox.Location = new System.Drawing.Point(274, 374);
            this.input11cTextBox.Name = "input11cTextBox";
            this.input11cTextBox.Size = new System.Drawing.Size(94, 22);
            this.input11cTextBox.TabIndex = 53;
            this.input11cTextBox.Text = "1.0";
            // 
            // input11bTextBox
            // 
            this.input11bTextBox.Location = new System.Drawing.Point(174, 374);
            this.input11bTextBox.Name = "input11bTextBox";
            this.input11bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input11bTextBox.TabIndex = 52;
            this.input11bTextBox.Text = "25";
            // 
            // input11aTextBox
            // 
            this.input11aTextBox.Location = new System.Drawing.Point(74, 374);
            this.input11aTextBox.Name = "input11aTextBox";
            this.input11aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input11aTextBox.TabIndex = 51;
            this.input11aTextBox.Text = "true";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(25, 377);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 17);
            this.label13.TabIndex = 50;
            this.label13.Text = "11:";
            // 
            // result12TextBox
            // 
            this.result12TextBox.Location = new System.Drawing.Point(574, 410);
            this.result12TextBox.Name = "result12TextBox";
            this.result12TextBox.ReadOnly = true;
            this.result12TextBox.Size = new System.Drawing.Size(94, 22);
            this.result12TextBox.TabIndex = 59;
            this.result12TextBox.TabStop = false;
            // 
            // input12cTextBox
            // 
            this.input12cTextBox.Location = new System.Drawing.Point(274, 410);
            this.input12cTextBox.Name = "input12cTextBox";
            this.input12cTextBox.Size = new System.Drawing.Size(94, 22);
            this.input12cTextBox.TabIndex = 58;
            this.input12cTextBox.Text = "1.0";
            // 
            // input12bTextBox
            // 
            this.input12bTextBox.Location = new System.Drawing.Point(174, 410);
            this.input12bTextBox.Name = "input12bTextBox";
            this.input12bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input12bTextBox.TabIndex = 57;
            this.input12bTextBox.Text = "25";
            // 
            // input12aTextBox
            // 
            this.input12aTextBox.Location = new System.Drawing.Point(74, 410);
            this.input12aTextBox.Name = "input12aTextBox";
            this.input12aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input12aTextBox.TabIndex = 56;
            this.input12aTextBox.Text = "true";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(25, 413);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 17);
            this.label14.TabIndex = 55;
            this.label14.Text = "12:";
            // 
            // result13TextBox
            // 
            this.result13TextBox.Location = new System.Drawing.Point(574, 447);
            this.result13TextBox.Name = "result13TextBox";
            this.result13TextBox.ReadOnly = true;
            this.result13TextBox.Size = new System.Drawing.Size(94, 22);
            this.result13TextBox.TabIndex = 64;
            this.result13TextBox.TabStop = false;
            // 
            // input13bTextBox
            // 
            this.input13bTextBox.Location = new System.Drawing.Point(174, 447);
            this.input13bTextBox.Name = "input13bTextBox";
            this.input13bTextBox.Size = new System.Drawing.Size(94, 22);
            this.input13bTextBox.TabIndex = 62;
            this.input13bTextBox.Text = "Electronics";
            // 
            // input13aTextBox
            // 
            this.input13aTextBox.Location = new System.Drawing.Point(74, 447);
            this.input13aTextBox.Name = "input13aTextBox";
            this.input13aTextBox.Size = new System.Drawing.Size(94, 22);
            this.input13aTextBox.TabIndex = 61;
            this.input13aTextBox.Text = "MN";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(25, 450);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 17);
            this.label15.TabIndex = 60;
            this.label15.Text = "13:";
            // 
            // FrmNetFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 608);
            this.Controls.Add(this.result13TextBox);
            this.Controls.Add(this.input13bTextBox);
            this.Controls.Add(this.input13aTextBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.result12TextBox);
            this.Controls.Add(this.input12cTextBox);
            this.Controls.Add(this.input12bTextBox);
            this.Controls.Add(this.input12aTextBox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.result11TextBox);
            this.Controls.Add(this.input11cTextBox);
            this.Controls.Add(this.input11bTextBox);
            this.Controls.Add(this.input11aTextBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.result01TextBox);
            this.Controls.Add(this.result02aTextBox);
            this.Controls.Add(this.result03bTextBox);
            this.Controls.Add(this.result03aTextBox);
            this.Controls.Add(this.result04bTextBox);
            this.Controls.Add(this.result04aTextBox);
            this.Controls.Add(this.result05bTextBox);
            this.Controls.Add(this.result05aTextBox);
            this.Controls.Add(this.result06bTextBox);
            this.Controls.Add(this.result06aTextBox);
            this.Controls.Add(this.result07TextBox);
            this.Controls.Add(this.result09bTextBox);
            this.Controls.Add(this.result10TextBox);
            this.Controls.Add(this.result09aTextBox);
            this.Controls.Add(this.result08TextBox);
            this.Controls.Add(this.buttonCalc);
            this.Controls.Add(this.input10dTextBox);
            this.Controls.Add(this.input10cTextBox);
            this.Controls.Add(this.input10bTextBox);
            this.Controls.Add(this.input10aTextBox);
            this.Controls.Add(this.input08eTextBox);
            this.Controls.Add(this.input09bTextBox);
            this.Controls.Add(this.input09aTextBox);
            this.Controls.Add(this.input08dTextBox);
            this.Controls.Add(this.input08cTextBox);
            this.Controls.Add(this.input08bTextBox);
            this.Controls.Add(this.input08aTextBox);
            this.Controls.Add(this.input07dTextBox);
            this.Controls.Add(this.input07cTextBox);
            this.Controls.Add(this.input07bTextBox);
            this.Controls.Add(this.input07aTextBox);
            this.Controls.Add(this.input03cTextBox);
            this.Controls.Add(this.input03bTextBox);
            this.Controls.Add(this.input03aTextBox);
            this.Controls.Add(this.input02aTextBox);
            this.Controls.Add(this.input01aTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrmNetFramework";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox input01aTextBox;
        private System.Windows.Forms.TextBox input02aTextBox;
        private System.Windows.Forms.TextBox input03aTextBox;
        private System.Windows.Forms.TextBox input03bTextBox;
        private System.Windows.Forms.TextBox input03cTextBox;
        private System.Windows.Forms.TextBox input07cTextBox;
        private System.Windows.Forms.TextBox input07bTextBox;
        private System.Windows.Forms.TextBox input07aTextBox;
        private System.Windows.Forms.TextBox input07dTextBox;
        private System.Windows.Forms.TextBox input08dTextBox;
        private System.Windows.Forms.TextBox input08cTextBox;
        private System.Windows.Forms.TextBox input08bTextBox;
        private System.Windows.Forms.TextBox input08aTextBox;
        private System.Windows.Forms.TextBox input08eTextBox;
        private System.Windows.Forms.TextBox input09bTextBox;
        private System.Windows.Forms.TextBox input09aTextBox;
        private System.Windows.Forms.TextBox input10dTextBox;
        private System.Windows.Forms.TextBox input10cTextBox;
        private System.Windows.Forms.TextBox input10bTextBox;
        private System.Windows.Forms.TextBox input10aTextBox;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.TextBox result08TextBox;
        private System.Windows.Forms.TextBox result09aTextBox;
        private System.Windows.Forms.TextBox result10TextBox;
        private System.Windows.Forms.TextBox result09bTextBox;
        private System.Windows.Forms.TextBox result07TextBox;
        private System.Windows.Forms.TextBox result06bTextBox;
        private System.Windows.Forms.TextBox result06aTextBox;
        private System.Windows.Forms.TextBox result05bTextBox;
        private System.Windows.Forms.TextBox result05aTextBox;
        private System.Windows.Forms.TextBox result04bTextBox;
        private System.Windows.Forms.TextBox result04aTextBox;
        private System.Windows.Forms.TextBox result03bTextBox;
        private System.Windows.Forms.TextBox result03aTextBox;
        private System.Windows.Forms.TextBox result02aTextBox;
        private System.Windows.Forms.TextBox result01TextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox result11TextBox;
        private System.Windows.Forms.TextBox input11cTextBox;
        private System.Windows.Forms.TextBox input11bTextBox;
        private System.Windows.Forms.TextBox input11aTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox result12TextBox;
        private System.Windows.Forms.TextBox input12cTextBox;
        private System.Windows.Forms.TextBox input12bTextBox;
        private System.Windows.Forms.TextBox input12aTextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox result13TextBox;
        private System.Windows.Forms.TextBox input13bTextBox;
        private System.Windows.Forms.TextBox input13aTextBox;
        private System.Windows.Forms.Label label15;
    }
}

