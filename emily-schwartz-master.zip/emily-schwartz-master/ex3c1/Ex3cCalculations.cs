﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex3c1
{
    public class Ex3cCalculations
    {
        public static string Calc0(int index)
        {
            string[] days = new string[7] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

            if (index >= 1 && index <= days.Length)
            {
                return days[index - 1].ToString();
            }
            else
                return "Invalid index";
        }

        public static string Calc1(string search)
        {
            string[] days = new string[7] { "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY" };
            string[] hours = new string[7] { "Closed", "10am - 6pm", "10am - 6pm", "10am - 6pm", "10am - 9pm", "10am - 6pm", "8am - 4pm" };

            if (search != "")
            {
                search = search.Trim();
                search = search.ToUpper();

                int index = Array.IndexOf(days, search);
                if (index != -1)
                {
                    return hours[index];
                }
                else
                    return "Invalid input";
            }
            else
            {
                search = "Invalid input";
                return search;
            }
        }

        public static int Calc2(int[] numbers)
        {
            int sum = 0;
            foreach (int numbers2 in numbers)
                sum += numbers2;
            return sum;
        }
        public static double Calc3(double[] numbers, int count)
        {
            double total = 0.0d;
            if (count <= numbers.GetLength(0))
            {
                for (int i = 0; i < count; i++)
                    total += numbers[i];
                return total;
            }
            else
            {
                return 0.0; 
            }
        }


        public static double Calc5(double[] numbers)
        {
            int count = numbers.GetLength(0);

            if (count > 0)
            {
                double total = Calc3(numbers, count);

                double average = total / count;
                return average;
            }
            else
                return -1;
        }

        public static double[] Calc6(double[] numbers)
        {
            int length = numbers.GetLength(0);
            List<double> aboveAvgList = new List<double>();
            if (length > 0)
            {
                double avg = Calc5(numbers);

                foreach (double number in numbers)
                {
                    if (number > avg)
                    {
                        aboveAvgList.Add(number);
                        //return aboveAvgList.ToArray();
                    }

                }
            }
            return aboveAvgList.ToArray();

        }
            
        }
    }
