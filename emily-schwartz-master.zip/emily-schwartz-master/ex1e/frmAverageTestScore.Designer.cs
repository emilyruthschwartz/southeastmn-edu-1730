﻿
namespace ex1e
{
    partial class frmAverageTestScore
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTestScore1 = new System.Windows.Forms.TextBox();
            this.txtTestScore2 = new System.Windows.Forms.TextBox();
            this.txtTestScore3 = new System.Windows.Forms.TextBox();
            this.txtAverageScore = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Test 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Test 2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Test 3:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Average:";
            // 
            // txtTestScore1
            // 
            this.txtTestScore1.Location = new System.Drawing.Point(116, 38);
            this.txtTestScore1.Name = "txtTestScore1";
            this.txtTestScore1.Size = new System.Drawing.Size(108, 27);
            this.txtTestScore1.TabIndex = 4;
            this.txtTestScore1.Text = "0";
            this.txtTestScore1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTestScore2
            // 
            this.txtTestScore2.Location = new System.Drawing.Point(116, 82);
            this.txtTestScore2.Name = "txtTestScore2";
            this.txtTestScore2.Size = new System.Drawing.Size(108, 27);
            this.txtTestScore2.TabIndex = 5;
            this.txtTestScore2.Text = "0";
            this.txtTestScore2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTestScore3
            // 
            this.txtTestScore3.Location = new System.Drawing.Point(116, 126);
            this.txtTestScore3.Name = "txtTestScore3";
            this.txtTestScore3.Size = new System.Drawing.Size(108, 27);
            this.txtTestScore3.TabIndex = 6;
            this.txtTestScore3.Text = "0";
            this.txtTestScore3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAverageScore
            // 
            this.txtAverageScore.Location = new System.Drawing.Point(116, 192);
            this.txtAverageScore.Name = "txtAverageScore";
            this.txtAverageScore.ReadOnly = true;
            this.txtAverageScore.Size = new System.Drawing.Size(108, 27);
            this.txtAverageScore.TabIndex = 7;
            this.txtAverageScore.TabStop = false;
            this.txtAverageScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(279, 37);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(94, 29);
            this.btnCalculate.TabIndex = 8;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(279, 80);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(94, 29);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "C&lear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(279, 120);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(94, 29);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmAverageTestScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 254);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtAverageScore);
            this.Controls.Add(this.txtTestScore3);
            this.Controls.Add(this.txtTestScore2);
            this.Controls.Add(this.txtTestScore1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmAverageTestScore";
            this.Text = "ex1e: Average Test Score";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTestScore1;
        private System.Windows.Forms.TextBox txtTestScore2;
        private System.Windows.Forms.TextBox txtTestScore3;
        private System.Windows.Forms.TextBox txtAverageScore;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

