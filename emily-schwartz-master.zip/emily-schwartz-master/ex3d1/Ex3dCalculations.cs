﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex3d1
{
    public class Ex3dCalculations
    {
        public static string ArrayToString(int[] values)
        {
            // Create StringBuilder object: sbResult
            
            StringBuilder sbResult = new StringBuilder(200);

            // loop foreach
            foreach (int value in values)
            {
                //     convert current value to string, append to sbResult
                value.ToString();
                sbResult.Append(value);

                //     append ", " to sbResult
                sbResult.Append(", ");
            }

            // convert sbResult to string: result
            string result = sbResult.ToString();

            // remove last ", " from result
            // return result

            return result.Remove(result.Length - 2);
        }

        public static int ValueCount(int[] values, int searchValue)
        {
            // create counter variable
            int count = 0;

            // loop
            foreach (int value in values)
            {
                //increment counter if current value equals searchValue
                if (value == searchValue)
                    count++;
            }
            //    
            // return counter
            return count;
        }

        public static int RangeCount(int[] values, int searchMin, int searchMax)
        {
            // create counter variable
            int count = 0;

            // loop
            foreach (int value in values)
            {
                //     increment counter if current value between min and max (inclusive)
                if (value >= searchMin && value <= searchMax)
                    count++;
            }
            // return counter
            return count;
        }
    }
}
