﻿
namespace ex2g1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.input1aTextBox = new System.Windows.Forms.TextBox();
            this.resultSwitch01TextBox = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.resultIf01TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.resultElseIf01TextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.resultNestedIfElse01TextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.resultSwitchDefault01TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.resultIfDefault01TextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.resultElseIfDefault01TextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.resultNestedIfElseDefault01TextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.resultNestedIfElse02TextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.resultIfElse02TextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.resultIf02TextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.resultSwitch02TextBox = new System.Windows.Forms.TextBox();
            this.input2aTextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "1) Switch R/C";
            // 
            // input1aTextBox
            // 
            this.input1aTextBox.Location = new System.Drawing.Point(232, 30);
            this.input1aTextBox.Name = "input1aTextBox";
            this.input1aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input1aTextBox.TabIndex = 1;
            this.input1aTextBox.Text = "R";
            // 
            // resultSwitch01TextBox
            // 
            this.resultSwitch01TextBox.Location = new System.Drawing.Point(444, 35);
            this.resultSwitch01TextBox.Name = "resultSwitch01TextBox";
            this.resultSwitch01TextBox.ReadOnly = true;
            this.resultSwitch01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultSwitch01TextBox.TabIndex = 2;
            this.resultSwitch01TextBox.TabStop = false;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(232, 500);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(105, 23);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calculate";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // resultIf01TextBox
            // 
            this.resultIf01TextBox.Location = new System.Drawing.Point(444, 66);
            this.resultIf01TextBox.Name = "resultIf01TextBox";
            this.resultIf01TextBox.ReadOnly = true;
            this.resultIf01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultIf01TextBox.TabIndex = 5;
            this.resultIf01TextBox.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "2) If R/C";
            // 
            // resultElseIf01TextBox
            // 
            this.resultElseIf01TextBox.Location = new System.Drawing.Point(444, 101);
            this.resultElseIf01TextBox.Name = "resultElseIf01TextBox";
            this.resultElseIf01TextBox.ReadOnly = true;
            this.resultElseIf01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultElseIf01TextBox.TabIndex = 7;
            this.resultElseIf01TextBox.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "3) Else If R/C";
            // 
            // resultNestedIfElse01TextBox
            // 
            this.resultNestedIfElse01TextBox.Location = new System.Drawing.Point(444, 131);
            this.resultNestedIfElse01TextBox.Name = "resultNestedIfElse01TextBox";
            this.resultNestedIfElse01TextBox.ReadOnly = true;
            this.resultNestedIfElse01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultNestedIfElse01TextBox.TabIndex = 9;
            this.resultNestedIfElse01TextBox.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "4) Nested If-else";
            // 
            // resultSwitchDefault01TextBox
            // 
            this.resultSwitchDefault01TextBox.Location = new System.Drawing.Point(444, 162);
            this.resultSwitchDefault01TextBox.Name = "resultSwitchDefault01TextBox";
            this.resultSwitchDefault01TextBox.ReadOnly = true;
            this.resultSwitchDefault01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultSwitchDefault01TextBox.TabIndex = 11;
            this.resultSwitchDefault01TextBox.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "5) Switch w/default";
            // 
            // resultIfDefault01TextBox
            // 
            this.resultIfDefault01TextBox.Location = new System.Drawing.Point(444, 193);
            this.resultIfDefault01TextBox.Name = "resultIfDefault01TextBox";
            this.resultIfDefault01TextBox.ReadOnly = true;
            this.resultIfDefault01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultIfDefault01TextBox.TabIndex = 13;
            this.resultIfDefault01TextBox.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(58, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "6) If R/C, default";
            // 
            // resultElseIfDefault01TextBox
            // 
            this.resultElseIfDefault01TextBox.Location = new System.Drawing.Point(444, 224);
            this.resultElseIfDefault01TextBox.Name = "resultElseIfDefault01TextBox";
            this.resultElseIfDefault01TextBox.ReadOnly = true;
            this.resultElseIfDefault01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultElseIfDefault01TextBox.TabIndex = 15;
            this.resultElseIfDefault01TextBox.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(58, 227);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "7) Else If R/C, default";
            // 
            // resultNestedIfElseDefault01TextBox
            // 
            this.resultNestedIfElseDefault01TextBox.Location = new System.Drawing.Point(444, 252);
            this.resultNestedIfElseDefault01TextBox.Name = "resultNestedIfElseDefault01TextBox";
            this.resultNestedIfElseDefault01TextBox.ReadOnly = true;
            this.resultNestedIfElseDefault01TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultNestedIfElseDefault01TextBox.TabIndex = 17;
            this.resultNestedIfElseDefault01TextBox.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(58, 256);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(163, 17);
            this.label8.TabIndex = 16;
            this.label8.Text = "8) Nested If-else, default";
            // 
            // resultNestedIfElse02TextBox
            // 
            this.resultNestedIfElse02TextBox.Location = new System.Drawing.Point(444, 380);
            this.resultNestedIfElse02TextBox.Name = "resultNestedIfElse02TextBox";
            this.resultNestedIfElse02TextBox.ReadOnly = true;
            this.resultNestedIfElse02TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultNestedIfElse02TextBox.TabIndex = 26;
            this.resultNestedIfElse02TextBox.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(58, 385);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 17);
            this.label9.TabIndex = 25;
            this.label9.Text = "4) Nested If-else";
            // 
            // resultIfElse02TextBox
            // 
            this.resultIfElse02TextBox.Location = new System.Drawing.Point(444, 350);
            this.resultIfElse02TextBox.Name = "resultIfElse02TextBox";
            this.resultIfElse02TextBox.ReadOnly = true;
            this.resultIfElse02TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultIfElse02TextBox.TabIndex = 24;
            this.resultIfElse02TextBox.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(58, 353);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 17);
            this.label10.TabIndex = 23;
            this.label10.Text = "3) Else If R/C";
            // 
            // resultIf02TextBox
            // 
            this.resultIf02TextBox.Location = new System.Drawing.Point(444, 315);
            this.resultIf02TextBox.Name = "resultIf02TextBox";
            this.resultIf02TextBox.ReadOnly = true;
            this.resultIf02TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultIf02TextBox.TabIndex = 22;
            this.resultIf02TextBox.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(58, 320);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 17);
            this.label11.TabIndex = 21;
            this.label11.Text = "2) If R/C";
            // 
            // resultSwitch02TextBox
            // 
            this.resultSwitch02TextBox.Location = new System.Drawing.Point(444, 284);
            this.resultSwitch02TextBox.Name = "resultSwitch02TextBox";
            this.resultSwitch02TextBox.ReadOnly = true;
            this.resultSwitch02TextBox.Size = new System.Drawing.Size(100, 22);
            this.resultSwitch02TextBox.TabIndex = 20;
            this.resultSwitch02TextBox.TabStop = false;
            // 
            // input2aTextBox
            // 
            this.input2aTextBox.Location = new System.Drawing.Point(232, 279);
            this.input2aTextBox.Name = "input2aTextBox";
            this.input2aTextBox.Size = new System.Drawing.Size(100, 22);
            this.input2aTextBox.TabIndex = 19;
            this.input2aTextBox.Text = "R";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(58, 284);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 17);
            this.label12.TabIndex = 18;
            this.label12.Text = "1) Switch R/C";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 556);
            this.Controls.Add(this.resultNestedIfElse02TextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.resultIfElse02TextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.resultIf02TextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.resultSwitch02TextBox);
            this.Controls.Add(this.input2aTextBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.resultNestedIfElseDefault01TextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.resultElseIfDefault01TextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.resultIfDefault01TextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.resultSwitchDefault01TextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.resultNestedIfElse01TextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.resultElseIf01TextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.resultIf01TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.resultSwitch01TextBox);
            this.Controls.Add(this.input1aTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "ex2g1: Switch, if-else";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox input1aTextBox;
        private System.Windows.Forms.TextBox resultSwitch01TextBox;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.TextBox resultIf01TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox resultElseIf01TextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox resultNestedIfElse01TextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox resultSwitchDefault01TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox resultIfDefault01TextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox resultElseIfDefault01TextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox resultNestedIfElseDefault01TextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox resultNestedIfElse02TextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox resultIfElse02TextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox resultIf02TextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox resultSwitch02TextBox;
        private System.Windows.Forms.TextBox input2aTextBox;
        private System.Windows.Forms.Label label12;
    }
}

