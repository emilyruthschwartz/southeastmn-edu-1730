﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ex1f
{
    public partial class frmCurrencyConverter2 : Form
    {
        public frmCurrencyConverter2()
        {
            InitializeComponent();
        }

        private void frmCurrencyConverter2_Load(object sender, EventArgs e)
        {
            btnChile.BackgroundImage = picChile.Image;
            btnEU.BackgroundImage = picEUDim.Image;
            btnIndonesia.BackgroundImage = picIndonesiaDim.Image;
            btnNZ.BackgroundImage = picNZDim.Image;
            txtRate.Text = "0.00110453";
            lblCurrency.Text = btnChile.Text + ":";
            txtUSD.Text = "0.00";
            txtTotalUSD.Text = "0.00";
            txtCurrency.Focus();
        }

        private void btnEU_Click(object sender, EventArgs e)
        {
            btnEU.BackgroundImage = picEU.Image;
            btnIndonesia.BackgroundImage = picIndonesiaDim.Image;
            btnNZ.BackgroundImage = picNZDim.Image;
            btnChile.BackgroundImage = picChileDim.Image;
            txtRate.Text = "1.00604";
            lblCurrency.Text = btnEU.Text + ":";
            txtCurrency.Focus();
        }

        private void btnIndonesia_Click(object sender, EventArgs e)
        {
            btnIndonesia.BackgroundImage = picIndonesia.Image;
            btnChile.BackgroundImage = picChileDim.Image;
            btnEU.BackgroundImage = picEUDim.Image;
            btnNZ.BackgroundImage = picNZDim.Image;
            txtRate.Text = "0.0000674243";
            lblCurrency.Text = btnIndonesia.Text + ":";
            txtCurrency.Focus();
        }

        private void btnNZ_Click(object sender, EventArgs e)
        {
            btnNZ.BackgroundImage = picNZ.Image;
            btnChile.BackgroundImage = picChileDim.Image;
            btnEU.BackgroundImage = picEUDim.Image;
            btnIndonesia.BackgroundImage = picIndonesiaDim.Image;
            txtRate.Text = "0.611925";
            lblCurrency.Text = btnNZ.Text + ":";
            txtCurrency.Focus();
        }

        private void btnChile_Click(object sender, EventArgs e)
        {
            btnChile.BackgroundImage = picChile.Image;
            btnEU.BackgroundImage = picEUDim.Image;
            btnIndonesia.BackgroundImage = picIndonesiaDim.Image;
            btnNZ.BackgroundImage = picNZDim.Image;
            txtRate.Text = "0.00110453";
            lblCurrency.Text = btnChile.Text + ":";
            txtCurrency.Focus();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            btnChile.BackgroundImage = picChile.Image;
            btnEU.BackgroundImage = picEUDim.Image;
            btnIndonesia.BackgroundImage = picIndonesiaDim.Image;
            btnNZ.BackgroundImage = picNZDim.Image;
            txtRate.Text = "0.00110453";
            lblCurrency.Text = btnChile.Text + ":";
            txtCurrency.Text = "0.00";
            txtUSD.Text = "0.00";
            txtTotalUSD.Text = "0.00";
            txtCurrency.Focus();
            lblEquation.Text = "";
            picChile.Image = btnChile.BackgroundImage;
        }

        private void calcUSD(object sender, EventArgs e)
        {
            txtUSD.Text = (
                Convert.ToDecimal(txtCurrency.Text) * Convert.ToDecimal(txtRate.Text)
                ).ToString("0.00");
        }
        private void txtCurrency_Enter(object sender, EventArgs e)
        {
            txtCurrency.SelectAll();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lblEquation.Text = lblEquation.Text + " + " + txtUSD.Text;
            txtTotalUSD.Text = (
                Convert.ToDecimal(txtTotalUSD.Text) + Convert.ToDecimal(txtUSD.Text)
                ).ToString("0.00");
            txtCurrency.Focus();
        }
        
    }
}
