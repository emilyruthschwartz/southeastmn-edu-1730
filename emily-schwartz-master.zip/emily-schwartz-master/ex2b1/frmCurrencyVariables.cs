﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ex2b1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculate(object sender, EventArgs e)
        {
            decimal amountChile = Convert.ToDecimal(txtAmountChile.Text);
            decimal rateChile = Convert.ToDecimal(txtRateChile.Text);
            decimal usdChile = amountChile * rateChile;
            txtUSDChile.Text = usdChile.ToString("0.00");

            decimal amountEuro = Convert.ToDecimal(txtAmountEuro.Text);
            decimal rateEuro = Convert.ToDecimal(txtRateEuro.Text);
            decimal usdEuro = amountEuro * rateEuro;
            txtUSDEuro.Text = usdEuro.ToString("0.00");

            decimal amountIndonesia = Convert.ToDecimal(txtAmountIndonesia.Text);
            decimal rateIndonesia = Convert.ToDecimal(txtRateIndonesia.Text);
            decimal usdIndonesia = amountIndonesia * rateIndonesia;
            txtUSDIndonesia.Text = usdIndonesia.ToString("0.00");

            decimal amountNewZealand = Convert.ToDecimal(txtAmountNewZealand.Text);
            decimal rateNewZealand = Convert.ToDecimal(txtRateNewZealand.Text);
            decimal usdNewZealand = amountNewZealand * rateNewZealand;
            txtUSDNewZealand.Text = usdNewZealand.ToString("0.00");

            decimal totalUSD = usdChile + usdEuro + usdIndonesia + usdNewZealand;
            txtTotalUSD.Text = totalUSD.ToString("0.00");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAmountChile.Text = "0.00";
            txtRateChile.Text = "0.0011279352";
            txtAmountEuro.Text = "0.00";
            txtRateEuro.Text = "1.002269";
            txtAmountIndonesia.Text = "0.00";
            txtRateIndonesia.Text = "0.000067348327";
            txtAmountNewZealand.Text = "0.00";
            txtRateNewZealand.Text = "0.61357518";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
