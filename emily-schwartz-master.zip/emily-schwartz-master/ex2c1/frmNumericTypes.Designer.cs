﻿
namespace ex2c1
{
    partial class frmNumericTypes
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.input1TextBox = new System.Windows.Forms.TextBox();
            this.input2TextBox = new System.Windows.Forms.TextBox();
            this.byte1TextBox = new System.Windows.Forms.TextBox();
            this.byte2TextBox = new System.Windows.Forms.TextBox();
            this.byte3TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.sbyte3TextBox = new System.Windows.Forms.TextBox();
            this.sbyte2TextBox = new System.Windows.Forms.TextBox();
            this.sbyte1TextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.short3TextBox = new System.Windows.Forms.TextBox();
            this.short2TextBox = new System.Windows.Forms.TextBox();
            this.short1TextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ushort3TextBox = new System.Windows.Forms.TextBox();
            this.ushort2TextBox = new System.Windows.Forms.TextBox();
            this.ushort1TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.int3TextBox = new System.Windows.Forms.TextBox();
            this.int2TextBox = new System.Windows.Forms.TextBox();
            this.int1TextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.uint3TextBox = new System.Windows.Forms.TextBox();
            this.uint2TextBox = new System.Windows.Forms.TextBox();
            this.uint1TextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.long3TextBox = new System.Windows.Forms.TextBox();
            this.long2TextBox = new System.Windows.Forms.TextBox();
            this.long1TextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ulong3TextBox = new System.Windows.Forms.TextBox();
            this.ulong2TextBox = new System.Windows.Forms.TextBox();
            this.ulong1TextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.float3TextBox = new System.Windows.Forms.TextBox();
            this.float2TextBox = new System.Windows.Forms.TextBox();
            this.float1TextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.double3TextBox = new System.Windows.Forms.TextBox();
            this.double2TextBox = new System.Windows.Forms.TextBox();
            this.double1TextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.decimal3TextBox = new System.Windows.Forms.TextBox();
            this.decimal2TextBox = new System.Windows.Forms.TextBox();
            this.decimal1TextBox = new System.Windows.Forms.TextBox();
            this.setMinButton = new System.Windows.Forms.Button();
            this.setMaxButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.subtractButton = new System.Windows.Forms.Button();
            this.multiplyButton = new System.Windows.Forms.Button();
            this.divideButton = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // input1TextBox
            // 
            this.input1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.input1TextBox.Location = new System.Drawing.Point(115, 56);
            this.input1TextBox.Name = "input1TextBox";
            this.input1TextBox.Size = new System.Drawing.Size(225, 25);
            this.input1TextBox.TabIndex = 0;
            this.input1TextBox.Text = "0";
            this.input1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.input1TextBox.TextChanged += new System.EventHandler(this.input1TextBox_TextChanged);
            // 
            // input2TextBox
            // 
            this.input2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.input2TextBox.Location = new System.Drawing.Point(361, 56);
            this.input2TextBox.Name = "input2TextBox";
            this.input2TextBox.Size = new System.Drawing.Size(225, 25);
            this.input2TextBox.TabIndex = 1;
            this.input2TextBox.Text = "0";
            this.input2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.input2TextBox.TextChanged += new System.EventHandler(this.input2TextBox_TextChanged);
            // 
            // byte1TextBox
            // 
            this.byte1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.byte1TextBox.Location = new System.Drawing.Point(115, 89);
            this.byte1TextBox.Name = "byte1TextBox";
            this.byte1TextBox.ReadOnly = true;
            this.byte1TextBox.Size = new System.Drawing.Size(225, 25);
            this.byte1TextBox.TabIndex = 2;
            this.byte1TextBox.TabStop = false;
            this.byte1TextBox.Text = "0";
            this.byte1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // byte2TextBox
            // 
            this.byte2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.byte2TextBox.Location = new System.Drawing.Point(361, 89);
            this.byte2TextBox.Name = "byte2TextBox";
            this.byte2TextBox.ReadOnly = true;
            this.byte2TextBox.Size = new System.Drawing.Size(225, 25);
            this.byte2TextBox.TabIndex = 3;
            this.byte2TextBox.TabStop = false;
            this.byte2TextBox.Text = "0";
            this.byte2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // byte3TextBox
            // 
            this.byte3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.byte3TextBox.Location = new System.Drawing.Point(615, 89);
            this.byte3TextBox.Name = "byte3TextBox";
            this.byte3TextBox.ReadOnly = true;
            this.byte3TextBox.Size = new System.Drawing.Size(225, 25);
            this.byte3TextBox.TabIndex = 4;
            this.byte3TextBox.TabStop = false;
            this.byte3TextBox.Text = "0";
            this.byte3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "byte:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "sbyte:";
            // 
            // sbyte3TextBox
            // 
            this.sbyte3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sbyte3TextBox.Location = new System.Drawing.Point(615, 124);
            this.sbyte3TextBox.Name = "sbyte3TextBox";
            this.sbyte3TextBox.ReadOnly = true;
            this.sbyte3TextBox.Size = new System.Drawing.Size(225, 25);
            this.sbyte3TextBox.TabIndex = 8;
            this.sbyte3TextBox.TabStop = false;
            this.sbyte3TextBox.Text = "0";
            this.sbyte3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // sbyte2TextBox
            // 
            this.sbyte2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sbyte2TextBox.Location = new System.Drawing.Point(361, 124);
            this.sbyte2TextBox.Name = "sbyte2TextBox";
            this.sbyte2TextBox.ReadOnly = true;
            this.sbyte2TextBox.Size = new System.Drawing.Size(225, 25);
            this.sbyte2TextBox.TabIndex = 7;
            this.sbyte2TextBox.TabStop = false;
            this.sbyte2TextBox.Text = "0";
            this.sbyte2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // sbyte1TextBox
            // 
            this.sbyte1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sbyte1TextBox.Location = new System.Drawing.Point(115, 124);
            this.sbyte1TextBox.Name = "sbyte1TextBox";
            this.sbyte1TextBox.ReadOnly = true;
            this.sbyte1TextBox.Size = new System.Drawing.Size(225, 25);
            this.sbyte1TextBox.TabIndex = 6;
            this.sbyte1TextBox.TabStop = false;
            this.sbyte1TextBox.Text = "0";
            this.sbyte1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "short:";
            // 
            // short3TextBox
            // 
            this.short3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.short3TextBox.Location = new System.Drawing.Point(615, 159);
            this.short3TextBox.Name = "short3TextBox";
            this.short3TextBox.ReadOnly = true;
            this.short3TextBox.Size = new System.Drawing.Size(225, 25);
            this.short3TextBox.TabIndex = 12;
            this.short3TextBox.TabStop = false;
            this.short3TextBox.Text = "0";
            this.short3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // short2TextBox
            // 
            this.short2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.short2TextBox.Location = new System.Drawing.Point(361, 159);
            this.short2TextBox.Name = "short2TextBox";
            this.short2TextBox.ReadOnly = true;
            this.short2TextBox.Size = new System.Drawing.Size(225, 25);
            this.short2TextBox.TabIndex = 11;
            this.short2TextBox.TabStop = false;
            this.short2TextBox.Text = "0";
            this.short2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // short1TextBox
            // 
            this.short1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.short1TextBox.Location = new System.Drawing.Point(115, 159);
            this.short1TextBox.Name = "short1TextBox";
            this.short1TextBox.ReadOnly = true;
            this.short1TextBox.Size = new System.Drawing.Size(225, 25);
            this.short1TextBox.TabIndex = 10;
            this.short1TextBox.TabStop = false;
            this.short1TextBox.Text = "0";
            this.short1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "ushort:";
            // 
            // ushort3TextBox
            // 
            this.ushort3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ushort3TextBox.Location = new System.Drawing.Point(615, 194);
            this.ushort3TextBox.Name = "ushort3TextBox";
            this.ushort3TextBox.ReadOnly = true;
            this.ushort3TextBox.Size = new System.Drawing.Size(225, 25);
            this.ushort3TextBox.TabIndex = 16;
            this.ushort3TextBox.TabStop = false;
            this.ushort3TextBox.Text = "0";
            this.ushort3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ushort2TextBox
            // 
            this.ushort2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ushort2TextBox.Location = new System.Drawing.Point(361, 194);
            this.ushort2TextBox.Name = "ushort2TextBox";
            this.ushort2TextBox.ReadOnly = true;
            this.ushort2TextBox.Size = new System.Drawing.Size(225, 25);
            this.ushort2TextBox.TabIndex = 15;
            this.ushort2TextBox.TabStop = false;
            this.ushort2TextBox.Text = "0";
            this.ushort2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ushort1TextBox
            // 
            this.ushort1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ushort1TextBox.Location = new System.Drawing.Point(115, 194);
            this.ushort1TextBox.Name = "ushort1TextBox";
            this.ushort1TextBox.ReadOnly = true;
            this.ushort1TextBox.Size = new System.Drawing.Size(225, 25);
            this.ushort1TextBox.TabIndex = 14;
            this.ushort1TextBox.TabStop = false;
            this.ushort1TextBox.Text = "0";
            this.ushort1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 20);
            this.label5.TabIndex = 21;
            this.label5.Text = "int:";
            // 
            // int3TextBox
            // 
            this.int3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.int3TextBox.Location = new System.Drawing.Point(615, 229);
            this.int3TextBox.Name = "int3TextBox";
            this.int3TextBox.ReadOnly = true;
            this.int3TextBox.Size = new System.Drawing.Size(225, 25);
            this.int3TextBox.TabIndex = 20;
            this.int3TextBox.TabStop = false;
            this.int3TextBox.Text = "0";
            this.int3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // int2TextBox
            // 
            this.int2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.int2TextBox.Location = new System.Drawing.Point(361, 229);
            this.int2TextBox.Name = "int2TextBox";
            this.int2TextBox.ReadOnly = true;
            this.int2TextBox.Size = new System.Drawing.Size(225, 25);
            this.int2TextBox.TabIndex = 19;
            this.int2TextBox.TabStop = false;
            this.int2TextBox.Text = "0";
            this.int2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // int1TextBox
            // 
            this.int1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.int1TextBox.Location = new System.Drawing.Point(115, 229);
            this.int1TextBox.Name = "int1TextBox";
            this.int1TextBox.ReadOnly = true;
            this.int1TextBox.Size = new System.Drawing.Size(225, 25);
            this.int1TextBox.TabIndex = 18;
            this.int1TextBox.TabStop = false;
            this.int1TextBox.Text = "0";
            this.int1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 264);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 20);
            this.label6.TabIndex = 25;
            this.label6.Text = "uint:";
            // 
            // uint3TextBox
            // 
            this.uint3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uint3TextBox.Location = new System.Drawing.Point(615, 264);
            this.uint3TextBox.Name = "uint3TextBox";
            this.uint3TextBox.ReadOnly = true;
            this.uint3TextBox.Size = new System.Drawing.Size(225, 25);
            this.uint3TextBox.TabIndex = 24;
            this.uint3TextBox.TabStop = false;
            this.uint3TextBox.Text = "0";
            this.uint3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // uint2TextBox
            // 
            this.uint2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uint2TextBox.Location = new System.Drawing.Point(361, 264);
            this.uint2TextBox.Name = "uint2TextBox";
            this.uint2TextBox.ReadOnly = true;
            this.uint2TextBox.Size = new System.Drawing.Size(225, 25);
            this.uint2TextBox.TabIndex = 23;
            this.uint2TextBox.TabStop = false;
            this.uint2TextBox.Text = "0";
            this.uint2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // uint1TextBox
            // 
            this.uint1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uint1TextBox.Location = new System.Drawing.Point(115, 264);
            this.uint1TextBox.Name = "uint1TextBox";
            this.uint1TextBox.ReadOnly = true;
            this.uint1TextBox.Size = new System.Drawing.Size(225, 25);
            this.uint1TextBox.TabIndex = 22;
            this.uint1TextBox.TabStop = false;
            this.uint1TextBox.Text = "0";
            this.uint1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 20);
            this.label7.TabIndex = 29;
            this.label7.Text = "long:";
            // 
            // long3TextBox
            // 
            this.long3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.long3TextBox.Location = new System.Drawing.Point(615, 299);
            this.long3TextBox.Name = "long3TextBox";
            this.long3TextBox.ReadOnly = true;
            this.long3TextBox.Size = new System.Drawing.Size(225, 25);
            this.long3TextBox.TabIndex = 28;
            this.long3TextBox.TabStop = false;
            this.long3TextBox.Text = "0";
            this.long3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // long2TextBox
            // 
            this.long2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.long2TextBox.Location = new System.Drawing.Point(361, 299);
            this.long2TextBox.Name = "long2TextBox";
            this.long2TextBox.ReadOnly = true;
            this.long2TextBox.Size = new System.Drawing.Size(225, 25);
            this.long2TextBox.TabIndex = 27;
            this.long2TextBox.TabStop = false;
            this.long2TextBox.Text = "0";
            this.long2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // long1TextBox
            // 
            this.long1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.long1TextBox.Location = new System.Drawing.Point(115, 299);
            this.long1TextBox.Name = "long1TextBox";
            this.long1TextBox.ReadOnly = true;
            this.long1TextBox.Size = new System.Drawing.Size(225, 25);
            this.long1TextBox.TabIndex = 26;
            this.long1TextBox.TabStop = false;
            this.long1TextBox.Text = "0";
            this.long1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 334);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "ulong:";
            // 
            // ulong3TextBox
            // 
            this.ulong3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ulong3TextBox.Location = new System.Drawing.Point(615, 334);
            this.ulong3TextBox.Name = "ulong3TextBox";
            this.ulong3TextBox.ReadOnly = true;
            this.ulong3TextBox.Size = new System.Drawing.Size(225, 25);
            this.ulong3TextBox.TabIndex = 32;
            this.ulong3TextBox.TabStop = false;
            this.ulong3TextBox.Text = "0";
            this.ulong3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ulong2TextBox
            // 
            this.ulong2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ulong2TextBox.Location = new System.Drawing.Point(361, 334);
            this.ulong2TextBox.Name = "ulong2TextBox";
            this.ulong2TextBox.ReadOnly = true;
            this.ulong2TextBox.Size = new System.Drawing.Size(225, 25);
            this.ulong2TextBox.TabIndex = 31;
            this.ulong2TextBox.TabStop = false;
            this.ulong2TextBox.Text = "0";
            this.ulong2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ulong1TextBox
            // 
            this.ulong1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ulong1TextBox.Location = new System.Drawing.Point(115, 334);
            this.ulong1TextBox.Name = "ulong1TextBox";
            this.ulong1TextBox.ReadOnly = true;
            this.ulong1TextBox.Size = new System.Drawing.Size(225, 25);
            this.ulong1TextBox.TabIndex = 30;
            this.ulong1TextBox.TabStop = false;
            this.ulong1TextBox.Text = "0";
            this.ulong1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(44, 369);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 20);
            this.label9.TabIndex = 37;
            this.label9.Text = "float:";
            // 
            // float3TextBox
            // 
            this.float3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.float3TextBox.Location = new System.Drawing.Point(615, 369);
            this.float3TextBox.Name = "float3TextBox";
            this.float3TextBox.ReadOnly = true;
            this.float3TextBox.Size = new System.Drawing.Size(225, 25);
            this.float3TextBox.TabIndex = 36;
            this.float3TextBox.TabStop = false;
            this.float3TextBox.Text = "0";
            this.float3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // float2TextBox
            // 
            this.float2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.float2TextBox.Location = new System.Drawing.Point(361, 369);
            this.float2TextBox.Name = "float2TextBox";
            this.float2TextBox.ReadOnly = true;
            this.float2TextBox.Size = new System.Drawing.Size(225, 25);
            this.float2TextBox.TabIndex = 35;
            this.float2TextBox.TabStop = false;
            this.float2TextBox.Text = "0";
            this.float2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // float1TextBox
            // 
            this.float1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.float1TextBox.Location = new System.Drawing.Point(115, 369);
            this.float1TextBox.Name = "float1TextBox";
            this.float1TextBox.ReadOnly = true;
            this.float1TextBox.Size = new System.Drawing.Size(225, 25);
            this.float1TextBox.TabIndex = 34;
            this.float1TextBox.TabStop = false;
            this.float1TextBox.Text = "0";
            this.float1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(44, 404);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 19);
            this.label10.TabIndex = 41;
            this.label10.Text = "double:";
            // 
            // double3TextBox
            // 
            this.double3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.double3TextBox.Location = new System.Drawing.Point(615, 404);
            this.double3TextBox.Name = "double3TextBox";
            this.double3TextBox.ReadOnly = true;
            this.double3TextBox.Size = new System.Drawing.Size(225, 25);
            this.double3TextBox.TabIndex = 40;
            this.double3TextBox.TabStop = false;
            this.double3TextBox.Text = "0";
            this.double3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // double2TextBox
            // 
            this.double2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.double2TextBox.Location = new System.Drawing.Point(361, 404);
            this.double2TextBox.Name = "double2TextBox";
            this.double2TextBox.ReadOnly = true;
            this.double2TextBox.Size = new System.Drawing.Size(225, 25);
            this.double2TextBox.TabIndex = 39;
            this.double2TextBox.TabStop = false;
            this.double2TextBox.Text = "0";
            this.double2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // double1TextBox
            // 
            this.double1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.double1TextBox.Location = new System.Drawing.Point(115, 404);
            this.double1TextBox.Name = "double1TextBox";
            this.double1TextBox.ReadOnly = true;
            this.double1TextBox.Size = new System.Drawing.Size(225, 25);
            this.double1TextBox.TabIndex = 38;
            this.double1TextBox.TabStop = false;
            this.double1TextBox.Text = "0";
            this.double1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(44, 439);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 19);
            this.label11.TabIndex = 45;
            this.label11.Text = "decimal:";
            // 
            // decimal3TextBox
            // 
            this.decimal3TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.decimal3TextBox.Location = new System.Drawing.Point(615, 439);
            this.decimal3TextBox.Name = "decimal3TextBox";
            this.decimal3TextBox.ReadOnly = true;
            this.decimal3TextBox.Size = new System.Drawing.Size(225, 25);
            this.decimal3TextBox.TabIndex = 44;
            this.decimal3TextBox.TabStop = false;
            this.decimal3TextBox.Text = "0";
            this.decimal3TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // decimal2TextBox
            // 
            this.decimal2TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.decimal2TextBox.Location = new System.Drawing.Point(361, 439);
            this.decimal2TextBox.Name = "decimal2TextBox";
            this.decimal2TextBox.ReadOnly = true;
            this.decimal2TextBox.Size = new System.Drawing.Size(225, 25);
            this.decimal2TextBox.TabIndex = 43;
            this.decimal2TextBox.TabStop = false;
            this.decimal2TextBox.Text = "0";
            this.decimal2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // decimal1TextBox
            // 
            this.decimal1TextBox.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.decimal1TextBox.Location = new System.Drawing.Point(115, 439);
            this.decimal1TextBox.Name = "decimal1TextBox";
            this.decimal1TextBox.ReadOnly = true;
            this.decimal1TextBox.Size = new System.Drawing.Size(225, 25);
            this.decimal1TextBox.TabIndex = 42;
            this.decimal1TextBox.TabStop = false;
            this.decimal1TextBox.Text = "0";
            this.decimal1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // setMinButton
            // 
            this.setMinButton.Location = new System.Drawing.Point(235, 21);
            this.setMinButton.Name = "setMinButton";
            this.setMinButton.Size = new System.Drawing.Size(110, 29);
            this.setMinButton.TabIndex = 46;
            this.setMinButton.Text = "Set Minimum";
            this.setMinButton.UseVisualStyleBackColor = true;
            this.setMinButton.Click += new System.EventHandler(this.setMinButton_Click);
            // 
            // setMaxButton
            // 
            this.setMaxButton.Location = new System.Drawing.Point(476, 21);
            this.setMaxButton.Name = "setMaxButton";
            this.setMaxButton.Size = new System.Drawing.Size(110, 29);
            this.setMaxButton.TabIndex = 47;
            this.setMaxButton.Text = "Set Maximum";
            this.setMaxButton.UseVisualStyleBackColor = true;
            this.setMaxButton.Click += new System.EventHandler(this.setMaxButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(615, 52);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(35, 29);
            this.addButton.TabIndex = 48;
            this.addButton.Text = "+";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // subtractButton
            // 
            this.subtractButton.Location = new System.Drawing.Point(656, 52);
            this.subtractButton.Name = "subtractButton";
            this.subtractButton.Size = new System.Drawing.Size(35, 29);
            this.subtractButton.TabIndex = 49;
            this.subtractButton.Text = "-";
            this.subtractButton.UseVisualStyleBackColor = true;
            this.subtractButton.Click += new System.EventHandler(this.subtractButton_Click);
            // 
            // multiplyButton
            // 
            this.multiplyButton.Location = new System.Drawing.Point(697, 52);
            this.multiplyButton.Name = "multiplyButton";
            this.multiplyButton.Size = new System.Drawing.Size(35, 29);
            this.multiplyButton.TabIndex = 50;
            this.multiplyButton.Text = "*";
            this.multiplyButton.UseVisualStyleBackColor = true;
            this.multiplyButton.Click += new System.EventHandler(this.multiplyButton_Click);
            // 
            // divideButton
            // 
            this.divideButton.Location = new System.Drawing.Point(738, 52);
            this.divideButton.Name = "divideButton";
            this.divideButton.Size = new System.Drawing.Size(35, 29);
            this.divideButton.TabIndex = 51;
            this.divideButton.Text = "/";
            this.divideButton.UseVisualStyleBackColor = true;
            this.divideButton.Click += new System.EventHandler(this.divideButton_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(669, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 20);
            this.label12.TabIndex = 52;
            this.label12.Text = "Result";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 515);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.divideButton);
            this.Controls.Add(this.multiplyButton);
            this.Controls.Add(this.subtractButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.setMaxButton);
            this.Controls.Add(this.setMinButton);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.decimal3TextBox);
            this.Controls.Add(this.decimal2TextBox);
            this.Controls.Add(this.decimal1TextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.double3TextBox);
            this.Controls.Add(this.double2TextBox);
            this.Controls.Add(this.double1TextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.float3TextBox);
            this.Controls.Add(this.float2TextBox);
            this.Controls.Add(this.float1TextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ulong3TextBox);
            this.Controls.Add(this.ulong2TextBox);
            this.Controls.Add(this.ulong1TextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.long3TextBox);
            this.Controls.Add(this.long2TextBox);
            this.Controls.Add(this.long1TextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.uint3TextBox);
            this.Controls.Add(this.uint2TextBox);
            this.Controls.Add(this.uint1TextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.int3TextBox);
            this.Controls.Add(this.int2TextBox);
            this.Controls.Add(this.int1TextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ushort3TextBox);
            this.Controls.Add(this.ushort2TextBox);
            this.Controls.Add(this.ushort1TextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.short3TextBox);
            this.Controls.Add(this.short2TextBox);
            this.Controls.Add(this.short1TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sbyte3TextBox);
            this.Controls.Add(this.sbyte2TextBox);
            this.Controls.Add(this.sbyte1TextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.byte3TextBox);
            this.Controls.Add(this.byte2TextBox);
            this.Controls.Add(this.byte1TextBox);
            this.Controls.Add(this.input2TextBox);
            this.Controls.Add(this.input1TextBox);
            this.Name = "Form1";
            this.Text = "ex2c: Numeric Types";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox input1TextBox;
        private System.Windows.Forms.TextBox input2TextBox;
        private System.Windows.Forms.TextBox byte1TextBox;
        private System.Windows.Forms.TextBox byte2TextBox;
        private System.Windows.Forms.TextBox byte3TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sbyte3TextBox;
        private System.Windows.Forms.TextBox sbyte2TextBox;
        private System.Windows.Forms.TextBox sbyte1TextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox short3TextBox;
        private System.Windows.Forms.TextBox short2TextBox;
        private System.Windows.Forms.TextBox short1TextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ushort3TextBox;
        private System.Windows.Forms.TextBox ushort2TextBox;
        private System.Windows.Forms.TextBox ushort1TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox int3TextBox;
        private System.Windows.Forms.TextBox int2TextBox;
        private System.Windows.Forms.TextBox int1TextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox uint3TextBox;
        private System.Windows.Forms.TextBox uint2TextBox;
        private System.Windows.Forms.TextBox uint1TextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox long3TextBox;
        private System.Windows.Forms.TextBox long2TextBox;
        private System.Windows.Forms.TextBox long1TextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ulong3TextBox;
        private System.Windows.Forms.TextBox ulong2TextBox;
        private System.Windows.Forms.TextBox ulong1TextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox float3TextBox;
        private System.Windows.Forms.TextBox float2TextBox;
        private System.Windows.Forms.TextBox float1TextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox double3TextBox;
        private System.Windows.Forms.TextBox double2TextBox;
        private System.Windows.Forms.TextBox double1TextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox decimal3TextBox;
        private System.Windows.Forms.TextBox decimal2TextBox;
        private System.Windows.Forms.TextBox decimal1TextBox;
        private System.Windows.Forms.Button setMinButton;
        private System.Windows.Forms.Button setMaxButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button subtractButton;
        private System.Windows.Forms.Button multiplyButton;
        private System.Windows.Forms.Button divideButton;
        private System.Windows.Forms.Label label12;
    }
}

